package Apache::OverSSI::DBM;

# $Id: DBM.pm,v 1.2 2004/08/08 19:14:28 jean Exp $

=head1 NAME

Apache::OverSSI::DBM - class for manipulation of DBM files

=head1 DESCRIPTION

Apache::OverSSI is a library for lightweight mod_perl
applications which use SSI for output templating.
based on Apache, mod_perl, mod_include and mod_env.

=over 4

=cut

use strict;
use warnings;

use Fcntl qw(:DEFAULT :flock);
use MLDBM qw(DB_File);
use DB_File;
use Symbol;

our $VERSION = sprintf("%d.%02d", '$Revision: 1.2 $' =~ /(\d+)\.(\d+)/);

use Apache::OverSSI::Exception;

#----------------------------------------------------------------------
use Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw( 	
    open_db
    close_db
);

#----------------------------------------------------------------------

=item open_db

open_db

=cut

sub open_db {
    my ($self, $name, $db, $lock) = @_; 

    my $file = $self->data_dir.'/'.$self->server->module_name.'-'.$name;

    # make lock
    my $fh = Symbol::gensym();
    unless ( open($fh,'>>',"$file.lock") ) {
	Exception->throw(code => 97, info => "error opening $file.lock ($!)");
	return undef;
    }
    unless ( flock($fh, $lock) ) {
	close ($fh);
	Exception->throw(code => 98, info => "error making lock $lock on $file.lock ($!)");
	return undef;
    }

    my $dbm = tie %$db, 'MLDBM', $file, O_CREAT|O_RDWR, 0600;
    unless ($dbm) {
	flock($fh, LOCK_UN);
	close($fh);
	Exception->throw(code => 99, info => "error opening $file ($!)");
	return undef;
    }
    my $dbh = { fh => $fh, dbm => $dbm, db => $db };
    return $dbh;
}

#----------------------------------------------------------------------

=item close_db

    close_db

=cut

sub close_db {
    my $self = shift;
    my $dbh = shift;
    undef $dbh->{'dbm'};
    untie %{$dbh->{'db'}};
    flock($dbh->{'fh'}, LOCK_UN);
    close($dbh->{'fh'});
}


#----------------------------------------------------------------------

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: DBM.pm,v 1.2 2004/08/08 19:14:28 jean Exp $

=cut

#######################################################################
