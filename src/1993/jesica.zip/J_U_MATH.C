// j__math

 #include "j__const.h"
 #include "j__shell.h"

 extern char *dsyms;
 extern int dsymnum, ddynelem;

 #define tprod struct ltprod
 #define thead struct lthead

 thead { char *name;
          int usef;
        tprod *fprod;
        tprod *truep;
        thead *next; };
 tprod { int prio;
         int numc;
       thead **listc;
       tprod *next; };

 static thead *rlistsym;
 static int rsymnum;
 static int rprodnum;
 static char **rlistname;
 static thead **rlistadr;
 static menuptr *rprodmnu;

 void prginst(), prglocal(), parkdata();

void prginst()
 { int i, j, cnt;
   char **ls0, **ls1, *y;
   tprod *lpr, *cpr;
   thead **cpos, *adr;
   extern thead *find(char *str);
   status ("��ନ஢���� �������� ������");
   mreadon(dsyms);
   y=mread();  // tittle
   rsymnum=rprodnum=0;
   cnt=dsymnum/ddynelem;
   ls0=salloc(ddynelem-1,sizeof(char *));
   while (cnt)
         { cnt--; y=mread(); adr=find(y);
           j=0; ls1=ls0;
           for (i=0;i<(ddynelem-1);i++)
               if (y=mread())
                { if (!equal(y,adr->name))
                  { *(ls1+j)=y; j++; }
                }
           if (!j) continue;
           cpr=salloc(1,sizeof(tprod));
           if (adr->fprod) { lpr=adr->fprod;
                              while (lpr->next) lpr=lpr->next;
                              lpr->next=cpr;
                            }
                       else { adr->fprod=cpr; rprodnum++; }
           cpr->prio=cpr->next=0;
           cpr->numc=j;
           cpr->listc=cpos=salloc(j,sizeof(thead *));
           while (j)
               { *cpos++=find(*ls1++); j--; }
         }
   rlistname=salloc(rprodnum,sizeof(char *));
   rlistadr =salloc(rprodnum,sizeof(thead *));
   adr=rlistsym;
   for (j=0;j<rprodnum;j++,adr=adr->next)
       { while (!adr->fprod) adr=adr->next;
         *(rlistname+j)=adr->name;
         *(rlistadr +j)=adr;
       }
   rprodmnu=menudyninit(rlistname,rprodnum,1,21,1,1);
   moutstr(0,1," �।��ࠡ�⪠ : ���� �뢮�� ����஥��",resatr,resatr);
  }

 void prglocal()
 { int i,j,k;
   char *ans, *ans1;
   thead *adr;
   extern int truefalse (thead *adr, thead *heap);
   extern void truelans  (thead *adr);
   status ("�롥�� ᨬ���, �뢮������� ���ண� ���� ��।�����");
   i=menudynact (rlistname,rprodmnu);
   if (i<0) return;
   ans1=(*(rlistadr+i))->name;
   adr=rlistsym;
   while (adr)
       { adr->usef=adr->truep=0;
         adr=adr->next;
       }
   moutstr (1,6,"*** �஢������ �த��� ",vdtatr,resatr);
   moutstr (0,0,ans1,vdvatr,resatr);
   j=truefalse (*(rlistadr+i),0);
   bell();
   moutstr (1,1,"��室�� ��ᨮ�� : ",vdtatr,resatr);
   adr=rlistsym; k=0;
   while (adr)
       { if (adr->usef==1 && adr->fprod==0)
          { if (k) moutstr(0,0,", ",resatr,resatr);
            moutstr (0,0,adr->name,vdvatr,resatr); k=1;
          }
         adr=adr->next;
       }
   if (k) moutstr(0,0,". ",resatr,resatr);
      else moutstr (0,0," ����������.",vdtatr,resatr);
   if (j)
    { status (" �᪮�� ᨬ��� �뢮��� �� �������� ��ᨮ���.");
      bell();
      j=1-askbin (0," ���᭨�� ������ �뢮�� ? ",0,0);
      ans=" �뢮���� �� �������� ��ᨮ���. ";
    }
      else ans=" �� �������� ��ᨮ��� �� �뢮����.";
   if (j)
    { moutstr(1,9,"���� �뢮�� :",vdtatr,resatr);
      truelans (*(rlistadr+i));
    }
   moutstr (1,1,"������� : �த��� ",vdtatr,resatr);
   moutstr (0,0,ans1,vdvatr,resatr);
   moutstr (0,0,ans,vdtatr,resatr);
   sfree(ans1);
   return;
 }

 void parkdata()
 {
   rsymnum=rprodnum=0;
   sfree(rprodmnu);
   sfree(rlistname);
   sfree(rlistadr);

   // �����᪨ ����室��� 㤠���� �� �����
   // ���筮-�ॢ������� ���...
   // ls0=salloc(ddynelem-1,sizeof(char *));
   // static thead *rlistsym;
   // static char **rlistname;
   // static thead **rlistadr;
 }

 static thead *find(char *str)
      { thead *adr, *adr1;
          int i,j;
        extern thead *new(char *str);
        if (!rsymnum) return rlistsym=new(str);
        adr=rlistsym;
        switch (strcmp(adr->name,str))
             { case -1 : break;
               case  0 : return adr;
               case  1 : adr=new(str); adr->next=rlistsym;
                         rlistsym=adr; return adr;
             }
        for (j=1;j<rsymnum;j++,adr=adr->next)
            { i=strcmp((adr->next)->name,str);
              if (i==0) return adr->next;
              if (i==1) break;
            }
        adr1=new(str);
        adr1->next=adr->next;
        adr->next=adr1;
        return adr1;
      }
 static thead *new(char *str)
      { thead *adr;
        adr=salloc(1,sizeof(thead));
        adr->name=str;
        adr->usef=adr->fprod=adr->next=0;
        rsymnum++;
        return adr;
      }

 static int truefalse (thead *adr, thead *heap)
      { int i, res;
        tprod *prod, *lprod;
        if (adr->usef) return !(adr->usef-1);
        if (!adr->fprod)
           { char *as, *a1, *a2;
             a1=makestr (" �� ��ᨮ�� ",adr->name);
             a2=makestr (a1," ������ �뢮������� �த�樨  ");
             sfree(a1);
             a1=makestr (a2,heap->name); sfree (a2);
             as=makestr(adr->name,"   ��୮ ? ");
             status (a1);
             i=askbin (0,as,0,0);
             sfree(a1);
             adr->usef=i+1;
             return !i;
           }
        prod=adr->fprod;
        do { res=1;
             for (i=0;i<prod->numc && res;i++)
                 res=truefalse(*(prod->listc+i),adr);
             if (!res) { lprod=prod; prod=prod->next; }
           } while (prod && !res);
        adr->usef=(!res)+1;
        if (!res) return 0;
        prod->prio++;
        adr->truep=prod;
        if (adr->fprod==prod) return 1;
        lprod->next=prod->next;
        if ((adr->fprod)->prio<prod->prio)
         { prod->next=adr->fprod;
           adr->fprod=prod;
           return 1;
         }
        lprod=adr->fprod;
        while (lprod->next && (lprod->next)->prio>=prod->prio)
              lprod=lprod->next;
        prod->next=lprod->next;
        lprod->next=prod;
        return 1;
      }

// ***************
 static void truelans  (thead *adr)
      { tprod *prod;
         char *a1, *a2;
          int i;
        moutstr(1,6,adr->name,vdvatr,resatr);
        if (!adr->fprod)
         { moutstr(0,0," - ��ᨮ��",resatr,resatr);
           return;
         }
           else moutstr(0,0," - �����祭�� �த�樨. ",resatr,resatr);
        moutstr (0,0," ��⨭�� ��������� ���뫪�� : ",resatr,resatr);
        prod=adr->truep;
        for (i=0;i<prod->numc;i++)
          { if (i) moutstr(0,0,", ",resatr,resatr);
            moutstr(0,0,(*(prod->listc+i))->name,vdvatr,resatr);
          }
        moutstr(0,0,".  ",resatr,resatr);
        for (i=0;i<prod->numc;i++) truelans(*(prod->listc+i));
      }

