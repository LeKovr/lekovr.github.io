package Apache::OverSSI::Utils;

# $Id: Utils.pm,v 1.4 2004/08/08 19:14:28 jean Exp $

=head1 NAME

Apache::OverSSI - Apache Over SSI core module

=head1 SYNOPSIS

  use Apache::OverSSI;

=head1 DESCRIPTION

Helper module for L<Apache::OverSSI> with standalone routines

The following methods are available:

=over 4

=cut

use 5.006;
use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw( 	
    escape_html
    pwd_eq
);

our $VERSION = sprintf("%d.%02d", '$Revision: 1.4 $' =~ /(\d+)\.(\d+)/);

#----------------------------------------------------------------------

=item escape_html

escape_html

=cut

sub escape_html {
    my $str = shift;
    return '' unless $str;
    $str =~ s '&'&amp;'g;		# ' - disables interpolation
    # escape quotes
    $str =~ s '\"'&quot;'g;		# ' - disables interpolation
    # disable tags
    $str =~ s '<'&lt;'g;		# ' - disables interpolation
    $str =~ s '>'&gt;'g;		# ' - disables interpolation
    $str =~ s '<'&lt;'g;		# ' - disables interpolation
    return $str;
}    



#----------------------------------------------------------------------

=item pwd_eq

pwd_eq

=cut

sub pwd_eq {
    my ($p1, $p2) = @_;
    return ($p2 and $p1 eq crypt($p2, substr($p1, 0, 2)));
}

#----------------------------------------------------------------------
1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: Utils.pm,v 1.4 2004/08/08 19:14:28 jean Exp $

=cut

#######################################################################

