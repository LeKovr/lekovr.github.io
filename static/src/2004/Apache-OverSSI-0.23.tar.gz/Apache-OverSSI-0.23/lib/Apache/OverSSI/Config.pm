package Apache::OverSSI::Config;

# $Id: Config.pm,v 1.1 2004/08/08 19:14:28 jean Exp $

=head1 NAME

Apache::OverSSI::Config - base class for config variables

=head1 DESCRIPTION

Apache::OverSSI is a library for lightweight mod_perl
applications which use SSI for output templating.
based on Apache, mod_perl, mod_include and mod_env.

=over 4

=cut
    
use strict;
use warnings;
use Params::Validate qw(:all);

use Class::Container;
use base qw(Class::Container);

our $VERSION = sprintf("%d.%02d", '$Revision: 1.1 $' =~ /(\d+)\.(\d+)/);

BEGIN {
    # Fields that can be set in new method, with defaults
    __PACKAGE__->valid_params (
	page_index => {
    	    type => SCALAR, default => '_page.shtml',
	    descr => 'Results template uri' 
	},
	page_error => {
    	    type => SCALAR | UNDEF, default => undef,
	    descr => "Page for display errors. INTERNAL_SERVER_ERROR will be returned if undef"
	},
	data_dir => {
    	    type => SCALAR, default => 'data',
	    descr => 'site level data directory (relative to $DOCUMENT_ROOT/../)' 
	},
	log_level => {
    	    type => SCALAR, default => 0,
	    descr => 'Log level' 
	},

	# Session handling
	cookie => {
    	    type => SCALAR, default => 'OverSSI_SID',
	    descr => 'Value from CookieName config variable' 
	},
	session_id => {
    	    type => SCALAR | UNDEF, default => undef,
	    descr => 'Value from CookieName config variable' 
	},
	session_logon => {
    	    type => SCALAR, default => '',
	    descr => 'uri to redirect for/after logon'
	},
    );
}

use Apache::OverSSI::MethodMaker (

    read_only => [ 
	keys %{__PACKAGE__->validation_spec}
    ],
);

#----------------------------------------------------------------------

=item page

page($tag) - return uri for tag

=cut

sub page { 
    my $self = shift;
    my $tag = shift;
    $tag = 'index' unless ($tag);
    
    return $self->{"page_$tag"};
}

#----------------------------------------------------------------------

1;


__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: Config.pm,v 1.1 2004/08/08 19:14:28 jean Exp $

=cut

#######################################################################
