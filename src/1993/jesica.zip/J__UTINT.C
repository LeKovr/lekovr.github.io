// j__utint

 #include "j__const.h"

 void *salloc (int num, int size);
 void sfree (void *pntt);
 int getblock (list **adr0,list **adr1,int size);
 void writeblock (line *blk,vars *vdef,char **lch,
		  int row,int wcol,int elem,
		  list *adr,int atr);
 void fulldata (int row,
			 int elem,
			 char *shab[],
			 char *lty,
			 line **blk,
			 vars **vdef,
			 int wcol,
			 int vatr,
			 int tatr);
 // ******  for calc
 void mreadon(char *ls);
 char *mread();
 void mfullstr (list *adr, int atr);
  void moutstr ( int x, int y,
	       char *str,        //  ��ப� ��� �뢮��
	      int tatr,int fatr);
 void moutpark (list **area1, int *mrow);

 int mreadint();
 void clmem (list *area, int mrow);
 void park(int i);

  #define bux struct lxxt
 bux { void *pnt;
	bux *next;
      };
 static bux *bux0, *bux1;
 static int buxnum=0;

 void *salloc( int num, int size)
    { void *p;
      if (!size) size=1;
       if (!buxnum) { bux0=bux1=calloc(1,sizeof(bux));
                      if (!bux0) {
                      message (0,"H������筮 ����⨢��� �����");
		      clrscr(); park(1);
	                         }
                      buxnum=1;
                    }
               else { bux1->next=calloc(1,sizeof(bux));
                      bux1=bux1->next; buxnum++;
                    }
      p=bux1->pnt=calloc(num,size);
      if (!p) { message (0,"H������筮 ����⨢��� �����");
		clrscr(); exit(1);
	      }
      return p;
    }
void sfree (void *pntt)
 { register int i;
   bux *buxl1,*buxl2;
   int fl=0;
   buxl1=bux0; buxl2=buxl1->next;
   if (buxnum) {
   if (buxl1->pnt==pntt) { fl=1; bux0=buxl2; free(buxl1);}
      else
           for (i=0;i<buxnum-1;i++)
                 { if ((buxl2)->pnt==pntt) { fl=1; buxl1->next=buxl2->next;
                                           free (buxl2); break;
                                          }
                   buxl1=buxl2; buxl2=buxl2->next;
                 }
                }
    if (fl) { free (pntt); buxnum--; }
//          else message (0,"null pointer assignment");
  }
 int getblock (list **adr0,list **adr1,int size)
 { list *p; int i;
   p=*adr0=salloc(size,sizeof(list));
   if (!p) return 0;
   for (i=1;i<size;i++,p++) (*p).next=p+1;
   *adr1=p;
   return 1;
 }

 void writeblock (line *blk,vars *vdef,char **lch,
		  int row,int wcol,int elem,
		  list *adr, int atr)
  { extern int limdblk;
    vars buf;
    int i,j,k,spn,fl;
    char *l1,*l2;
    if (elem) buf=*vdef++;  else buf.x=buf.y=-1;
    if (lch==0) fl=1; else fl=0;
    for (i=0;i<row;i++,blk++,adr++)
	for (j=0;j<wcol;j++)
	    if (buf.x !=i || buf.y!=j ) (*adr).dat[j]=(*blk)[j];
	       else { if (fl) { for (spn=0;spn<buf.len;spn++,j++)
				    { (*adr).dat[j].ch=(*blk)[j].ch;
				      (*adr).dat[j].at=atr;
				    }
				 j--;
			      }
		       else { l2=l1=salloc(buf.len+1,sizeof(char));k=0;
			      while (**lch!=DELIM)
				    { *l2=(**lch); k++;l2++;(*lch)++;}
			      if (buf.type==2)
				 { *l2='\0'; limdblk=atoi(l1); }
			      (*lch)++;spn=buf.len-k;l2=l1;
			      while (spn) { (*adr).dat[j].ch=(*blk)[j].ch;
					    (*adr).dat[j].at=atr;
					    j++; spn--; }
			      while (k) { (*adr).dat[j].ch=*l1++;
					  (*adr).dat[j].at=(*blk)[j].at;
					  k--; j++;
					}
			      sfree(l2); j--;
			    }
		      elem--;
		      if (elem) buf=*vdef++; else buf.x=buf.y=-1;
		    }
  }

 static     line *bp;
  void fulldata (int row,int elem,
		 char *shab[],
		 char *lty,
		 line **blk,
		 vars **vdef,
		 int wcol,int vatr,int tatr)
    { extern void tomem (char ch,char at, int lj);
      static char *pnt;
      vars *ep;
      char *p;
      int i,a,b,len,j ;
      if (lty!=0) { pnt = lty; }
      if (elem) ep=*vdef=salloc(elem,sizeof(vars)); else *vdef=0;
      if (row) { bp=*blk=salloc(row,sizeof(line));
		 for (i=0;i<row;i++,bp++)
		 { b=strlen(shab[i]);a=(wcol-b)/2;
		   p=shab[i]; b+=a;
		   for (j=0;j<wcol;j++)
		      {
		       if ((j<a) || (j>=b)) tomem(' ',tatr,j);
		       else if ((*p) != '/') { tomem (*p,tatr,j);
					     p++;}
			    else {    //  var
				   (*ep).type=(*pnt++)-'0';
				   (*ep).x=i; (*ep).y=j;len=0;
				   while (*p == '/')
					 { len++; tomem(VMASK,vatr,j);
					   j++; p++;
					 }
					 j--; (*ep).len=len;
					 ep++;
				 }
		     }
		 }
	       }
	  else *blk=0;
    }
  void tomem (char ch,char at, int lj)
  { (*bp)[lj].ch=ch;
    (*bp)[lj].at=at;

  }

  void park (int i)
 { register int j;
   bux *buxl1,*buxl2;
   int fl=0;
   bell();bell();bell();
   oldscreen("on");
   buxl1=bux0; buxl2=buxl1->next;
   if (buxnum) {
           for (j=0;j<buxnum;j++)
           { free (buxl1->pnt); free(buxl1);
             buxl1=buxl2;  buxl2=buxl2->next;
           }
               }
//    menulineclose();
//    goto_xy(10,10);
//    printf ("  divided by zero -> %d",buxnum);
//    getch();
    fcloseall();
    exit (i);
    }
 // ************  ����䥩� ������ ***************

 static char *lsvar;
 void mreadon(char *ls)
    { lsvar=ls;
    }

 char *mread ()
 { int i,j;
   char *c;
   for (i=0;*(lsvar+i)!=DELIM && *(lsvar+i)!='\0';i++);
   if (!i) { lsvar++; return '\0'; }
   c=salloc(i+1,sizeof(char));
   for (j=0;j<i;j++) *(c+j)=*lsvar++;
   lsvar++; *(c+i)='\0';
   return c;
   }

 static list *mstrpnt;
 static int mmaxrow, mcurcol;
 void moutini (list *adr, int atr)
    { local1 a;
      int i;
      a.ch=' '; a.at=atr;
      for (i=0;i<maxsym;i++) adr->dat[i]=a;
      mstrpnt=adr;
      mmaxrow=0;
      mcurcol=1;
    }

 void moutstr ( int x, int y,
	       char *str,        //  ��ப� ��� �뢮��
	      int tatr,int fatr)
  {
    int i,k,k1;
    if (y) mcurcol=y;
    k=strlen(str);
    if (mcurcol+k>=maxsym-1) { x++; y=0; }
    if (x)
       { local1 a;
         a.ch=' '; a.at=fatr;
         mcurcol=1;
         while (x)
	     { mstrpnt->next=salloc(1,sizeof(list));
	       mmaxrow++; mstrpnt=mstrpnt->next;
               for (i=0;i<maxsym;i++) mstrpnt->dat[i]=a;
	       x--;
	     }
       }
   if (y) mcurcol=y;
   if (!k) { mcurcol=1; return; }
   if ((mcurcol+k+1)>maxsym)
      { k1=k; k=maxsym-mcurcol-1;
        k1-=k;
      }
    else k1=0;
   for (i=0;i<k;i++)
       { mstrpnt->dat[mcurcol].ch=*(str+i);
	 mstrpnt->dat[mcurcol++].at=tatr;
       }
 if (k1) moutstr (1,0,str+k,tatr,fatr);
 }

 void moutpark (list **area1, int *mrow)
    { *area1=mstrpnt;
      *mrow+=mmaxrow;
    }
 void clmem (list *area, int mrow)
    { list *p1, *p2;
      int i;
      p1=area;
      for (i=0;i<mrow;i++)
         { p2=p1;
           p1=p1->next;
           sfree (p2);
         }
 }


