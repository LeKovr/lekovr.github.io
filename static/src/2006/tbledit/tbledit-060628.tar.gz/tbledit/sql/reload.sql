delete from row_config where config_id = 2;
delete from tbledit_config where config_id = 2;

insert into tbledit_config 
  select 2, 
table_title,
 table_keys,
 fields_sql,
 table_fields,
 table_sql,
 row_sql,
 del_sql,
 upd_sql,
 ins_sql,
 upd_fields,
 tmpl_table,
 tmpl_row,
 tmpl_row_edit,
 tmpl_saved,
 tmpl_deleted,
 tmpl_error,
 fmt_header,
 fmt_tablerow,
 fmt_row,
 fmt_view,
 fmt_edit,
 fmt_ins,
 fmt_del
 from tbledit_config where config_id = 1
;

insert into row_config 
  select 2,
    field_name,
    type_id,
    order_id,
    is_readonly,
    is_escape,
    vdefault,
    type_def,
    name,
    note
    from row_config where config_id = 1
;
