package TblEdit::Template;

# $Id: Template.pm,v 1.3 2006/06/27 20:18:51 jean Exp $

=head1 NAME

TblEdit::Template - ���������� ��� ������������ html � �����������,
����������� � ����

=head1 DESCRIPTION


=over 4

=cut

use strict;
use warnings;

our $VERSION = '0.10';
our $REVISION = sprintf("%d.%02d", '$Revision: 1.3 $' =~ /(\d+)\.(\d+)/);

# -----------------------------------------------------------------------------

use Data::Dumper;
# $Id: Template.pm,v 1.3 2006/06/27 20:18:51 jean Exp $
# CGI launcher

use strict;
use warnings;

use constant  CONFIG => qw(tmpl_table tmpl_row tmpl_row_edit tmpl_saved tmpl_deleted tmpl_error);
use constant  DIR => 'templates';

use fields ( qw(root), (CONFIG) );

# -----------------------------------------------------------------------------
sub new
{
  my $class = shift;
  my $self = fields::new($class);
  $self->{'root'} = shift;
  my %c = @_;
  foreach my $field ( (CONFIG) ) { $self->{$field} = $c{$field} }
  return $self;
}

# -----------------------------------------------------------------------------
# code from Perl Cookbook 
# Recipe 20.9. Creating HTML Templates 
# perl/cd/cookbook/ch20_10.htm
sub run
{
 my $self = shift;
 my $tag = shift;
 my $data = shift;

 my $filename = join '/', $self->{'root'}, DIR, $self->{$tag};
 my $fillings = $data;
 my $text;
 local $/;                   # slurp mode (undef)
 local *F;                   # create local filehandle
 open(F, "< $filename\0")    || die 'Template not found: '.$filename;
 $text = <F>;                # read whole file
 close(F);                   # ignore retval
 # replace quoted words with value in %$fillings hash
 $text =~ s{ %% ( .*? ) %% }
           {
            exists( $fillings->{$1} )
            ? $fillings->{$1}
            : ""
           }gsex;
  return $text;
}

# -----------------------------------------------------------------------------

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <jean@jast.ru>

=head1 VERSION

    $Id: Template.pm,v 1.3 2006/06/27 20:18:51 jean Exp $

=cut

###############################################################################
