// j__lib


 #include <fcntl.h>
 #include <io.h>
 #include <stdio.h>
 #include "j__const.h"

 extern char *flname;
 menuptr *dinpmnu;
 int numlib;
 char *buflib, **datlib;

 void readlib ();


  void readlib ()
 { char *p,*r,*r0,*ll;
   int i,j,f,cnt,str,nf,fl=0;
   unsigned int bytec;
   status ("���䨪��� ������⥪� �室��� ������");numlib=0;
   p=makestr(flname,".fls"); *datlib=kbd;
   if ((f=_open(p,O_RDONLY))==-1) return;
   bytec=filelength(f);
   if (!bytec) return;
   p=buflib=salloc(bytec,sizeof(char));
   _read(f,buflib,bytec); _close(f);
   r=salloc(libdigit+1,sizeof(char)); i=0; cnt=0;
   while ('0'<=*(p+cnt) && *(p+cnt)<='9' && cnt<libdigit) *(r+cnt)=*(p+cnt++);
   *(r+cnt)='\0'; while (*(p+cnt)!=10) cnt++;
   cnt++;
   i=atoi(r);  //  ������⢮ ��ப � ����
   datlib=salloc(i+1,sizeof(char *));
   *datlib=kbd; str=1;
   if (!i) return;
       // str ����� ����饣��� 䠩��
   while (str<=i && cnt<=bytec)
	 { int j;
	   // �ଠ� ��ப : nn note
	   ll=p+cnt;
	   for (j=0;j<libdigit && *(p+cnt)!=' ';j++,cnt++);
	   *(p+cnt++)='\0';
	   nf=atoi(ll);
	   ll=makefln(nf);
	   if (access(ll,04)==0)
	       { *(datlib+str)=p+cnt;
		 numlib++;
		 if (nf!=str)
		    { char *ll1;
                      fl=1;
		      // rename ll ll1
		      ll1=makefln(str);
	 //     if (rename (ll,ll1)==0) { numlib--;str--;}
                      sfree(ll1);
		    }
		str++;
	      }
	  while (*(p+cnt)!='\n') cnt++;
	  *(p+cnt++)='\0';
	}
     if (fl) message(0,"����襭� 楫��⭮��� ������⥪�");
   status (" ");
   if (numlib)
      { sfree (dinpmnu);
        dinpmnu=menudyninit(datlib,numlib+1,1,21,1,1);
      }
   return ;
 }



