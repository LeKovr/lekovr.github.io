package Apache::OverSSI::DBI;

# $Id: DBI.pm,v 1.4 2004/11/25 19:10:04 aleko Exp $

=head1 NAME

Apache::OverSSI::DBM - class for manipulation with DBI

=head1 DESCRIPTION

Apache::OverSSI is a library for lightweight mod_perl
applications which use SSI for output templating.
based on Apache, mod_perl, mod_include and mod_env.

=over 4

=cut

use strict;
use warnings;

use POSIX qw(ceil);

use DBI;

our $VERSION = sprintf("%d.%02d", '$Revision: 1.4 $' =~ /(\d+)\.(\d+)/);

use Apache::OverSSI::Exception;

#----------------------------------------------------------------------
use Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw( 	
    db_connect
    db_select
);

#----------------------------------------------------------------------

=item db_connect

db_connect

=cut

sub db_connect {
    my ($conf) = @_; 

    return DBI->connect($conf->dbi_dsn, $conf->dbi_user, $conf->dbi_auth) 
	or Exception->throw(code=>'01', info => $DBI::errstr);

}

#----------------------------------------------------------------------

=item db_select

    db_select

=cut

sub db_select {
    my ($dbh, $sql, $args, $limit, $page) = @_;

    my $csql = "select count(*) from ( $sql ) temp_table_$$";

    my $sth = $dbh->prepare($csql) or Exception->throw(code=>'01', info =>  $DBI::errstr);
    my $rv= $sth->execute(@$args) or Exception->throw(code=>'01', info =>  $DBI::errstr);
    my $result = $sth->fetchrow_arrayref() or  Exception->throw(code=>'01', info =>  $DBI::errstr);

    my $rows = $result->[0] or return undef;

    if ($limit == -1) {
	# fetch all records
	$limit = $rows;
	$page = 1;
    }

    my $pages = ceil($rows / $limit);
    $page = 1 if (!$page or $page<1);
    $page = $pages if ($page > $pages);
    my $offset = ($page-1) * $limit;
    
    $sql = $sql." limit $limit offset $offset";

    $sth = $dbh->prepare($sql) or Exception->throw(code=>'01', info =>  $dbh->errstr);
    $rv = $sth->execute(@$args) or Exception->throw(code=>'01', info =>  $DBI::errstr);

    #----------------------------------------------------------------------
    my $data = $sth->fetchall_arrayref() or Exception->throw(code=>'01', info => $dbh->errstr);

    return undef unless scalar @$data;

    my ($first, $last, $prev, $next);
    if ($pages) {
        # ����� 1� ������ �� ��������
        $first = $limit * ($page - 1) + 1;

        # ����� ��������� ������
        $last = $limit * $page;
        $last = $rows if ($last > $rows);

        # ���������� ��������
        $prev = $page-1 if ($page > 1);

        # ��������� ��������
        $next = $page+1 if ($page<$pages);
    } else {
	$first = 1;
	$last = $rows;
    }
    my $navy = { rows => $rows, page => $page, pages => $pages, limit => $limit,
		first => $first, last => $last, prev => $prev, next => $next,
		data => $data
    };
    return $navy;
}


#----------------------------------------------------------------------

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: DBI.pm,v 1.4 2004/11/25 19:10:04 aleko Exp $

=cut

#######################################################################
