package TblEdit::DB;

# $Id: DB.pm,v 1.2 2006/06/26 19:29:12 jean Exp $

=head1 NAME

TblEdit::DB - ���������� ��� ������� � ��

=head1 DESCRIPTION


=over 4

=cut

use strict;
use warnings;

our $VERSION = '0.10';
our $REVISION = sprintf("%d.%02d", '$Revision: 1.2 $' =~ /(\d+)\.(\d+)/);

# -----------------------------------------------------------------------------

use DBI;

use constant  CONFIG => qw(DSN USER AUTH);

use fields qw(_dbh);

# -----------------------------------------------------------------------------

sub new
{
  my $class = shift;
  my $self = fields::new($class);
#  my %c = @_;
  my $c = shift;
  $self->{'_dbh'} = DBI->connect( map { $c->{$_} } (CONFIG) )
    or die "connect error: $!";
  return $self;
}

# -----------------------------------------------------------------------------
sub hash
{
  my $self = shift;
  my $sql = shift;
  my $ret = $self->{'_dbh'}->selectrow_hashref($sql, undef, @_)
    or die "DB::hash error with SQL ($sql):".$self->{'_dbh'}->errstr ;
  return $ret;
}


# -----------------------------------------------------------------------------
sub array_hash
{
  my $self = shift;
  my $sql = shift;
  my $ret = $self->{'_dbh'}->selectall_arrayref($sql, { 'Slice' => {} })
    or die "DB::array_hash error with SQL ($sql):".$self->{'_dbh'}->errstr ;
  return $ret;
}

# -----------------------------------------------------------------------------
sub array_array
{
  my $self = shift;
  my $sql = shift;
  my $ret = $self->{'_dbh'}->selectall_arrayref($sql, undef, @_)
    or die "DB::array_array error with SQL ($sql):".$self->{'_dbh'}->errstr ;
  return $ret;
}

# -----------------------------------------------------------------------------
sub do
{
  my $self = shift;
  return $self->{'_dbh'}->do(@_);
}

# -----------------------------------------------------------------------------
sub errstr
{
  return shift->{'_dbh'}->errstr;
}

# -----------------------------------------------------------------------------

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <jean@jast.ru>

=head1 VERSION

    $Id: DB.pm,v 1.2 2006/06/26 19:29:12 jean Exp $

=cut

###############################################################################
