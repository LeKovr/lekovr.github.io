package Apache::OverSSIApp::AuthConfig;

# $Id: AuthConfig.pm,v 1.2 2004/08/08 19:14:45 jean Exp $

=head1 NAME

Apache::OverSSIApp::AuthConfig - Internal package

=head1 DESCRIPTION


=over 4

=cut
    
use strict;
use warnings;

use Params::Validate qw(:all);

use base qw(Apache::OverSSI::Config);

our $VERSION = sprintf("%d.%02d", '$Revision: 1.2 $' =~ /(\d+)\.(\d+)/);

BEGIN {
    __PACKAGE__->valid_params (
	dbi_dsn => {
    	    type => SCALAR,
	    descr => 'DBI connect DSN' 
	},
	dbi_user => {
    	    type => SCALAR,
	    descr => 'DBI connect user' 
	},
	dbi_auth => {
    	    type => SCALAR,
	    descr => 'DBI connect password' 
	},
	sql => {
    	    type => SCALAR,
	    descr => 'SQL for data fetch users data from db (will be stored in session hash)' 
	},
	auth_field => {
    	    type => SCALAR,
	    descr => 'name of password field in SQL result' 
	},
	use_crypt => {
    	    type => SCALAR, default => 0,
	    descr => 'use crypt in password compare' 
	},
	session_logout => {
    	    type => SCALAR, default => '',
	    descr => 'uri to redirect after logout'
	},

	# EXTENDED	- run in extended mode ( with register/newpass/restore)
	# FLD_EMAIL	- field to fetch user's email from
	# SQL_PASS	- query to change password
    );
}

use Apache::OverSSI::MethodMaker (
    read_only => [ 
	keys %{__PACKAGE__->validation_spec}
    ],
);

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: AuthConfig.pm,v 1.2 2004/08/08 19:14:45 jean Exp $

=cut

#######################################################################
