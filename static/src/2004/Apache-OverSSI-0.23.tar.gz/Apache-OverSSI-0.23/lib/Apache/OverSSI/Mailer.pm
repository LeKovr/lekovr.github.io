package Apache::OverSSI::Mailer;

# $Id: Mailer.pm,v 1.4 2004/08/08 19:14:28 jean Exp $

=head1 NAME

Apache::OverSSI - Apache Over SSI core module

=head1 SYNOPSIS

  use Apache::OverSSI;

=head1 DESCRIPTION

Helper module for sending mails from L<Apache::OverSSI>

The following methods are available:


=over 4

=cut

use 5.006;
use strict;
use warnings;

require Exporter;

use IPC::Open2;
use Net::SMTP;

our @ISA = qw(Exporter);

our @EXPORT = qw( 	
	    mail_test
	    mail_key
	    );

use Apache::OverSSI::Exception;

our $VERSION = sprintf("%d.%02d", '$Revision: 1.4 $' =~ /(\d+)\.(\d+)/);

#----------------------------------------------------------------------

=item mail_test

mail_test - returns '' if address is OK

=cut
 
sub mail_test {
    my ($s, $line)= @_;

    # ToDo: USE Net::SMTP
    my $prog = '/usr/sbin/sendmail';

    if ($line eq '') { return '&nbsp;'; }

    my $pid = open2( \*Reader, \*MAIL, "$prog -bv $line" );
    MAIL->autoflush(); # default here, actually
    close (MAIL);
    $line='';
    while ( <Reader> ) {
        if (/(.+)... User unknown/i) { $line.="$1"; }
    }
    close(Reader);
    return $line;
}

#----------------------------------------------------------------------

=item mail_key

Send contents of MAIL SSI variable via email

=cut

sub mail_key {
    my ($s, $to) = @_;
    my $r = $s->request;
    my $server = $r->server->server_hostname();
    my $from = $s->config->from;
    my $mail = $s->config->mail;
    eval {
        # init the server
        my $smtp = Net::SMTP->new($s->config->smtp, Timeout => 60, Debug   => 0,
                                Hello => $server )
                                or die "Failed to new $!" ;

        $smtp->mail($from) or die "Failed to specify a sender [$from] $!\n";
        $smtp->to($to) or die "Failed to specify a recipient [$to] $!\n";
        $smtp->data("To: $to\n$mail") or die "Failed to send a message $!\n";
	$smtp->quit or die "Failed to quit\n";
    };
    if ($@) {
	Exception->throw(code=>'05',info=>"RCPT ($to): $@");
    }

    return undef;
}

#----------------------------------------------------------------------
1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: Mailer.pm,v 1.4 2004/08/08 19:14:28 jean Exp $

=cut

#######################################################################
