package Apache::OverSSI;

# $Id: OverSSI.pm,v 1.14 2004/11/25 19:11:56 aleko Exp $

=head1 NAME

Apache::OverSSI - mod_perl application library based on SSI templating

=head1 DESCRIPTION

Apache::OverSSI is a library for lightweight mod_perl
applications which use SSI for output templating.
based on Apache, mod_perl, mod_include and mod_env.

=over 4

=cut
    
use 5.005;
use strict;
use Apache;
use Apache::Request;
use Apache::Constants ':common';

our $VERSION = '0.23';
our $REVISION = sprintf("%d.%02d", '$Revision: 1.14 $' =~ /(\d+)\.(\d+)/);

#----------------------------------------------------------------------

=item table

Usage:

In program code before include:

    my $tst = [
	    [ 1, 2, 3, 4, 5 ],
	    [ 1, 2, 3, 4, 5 ],
	    [ 1, 2, 3, 4, 5 ],
	    [ 1, 2, 3, 4, 5 ],
    ];

    $args->{'D_TBL1'}='SSI_TBL1';
    $r->pnotes ('SSI_TBL1', $tst);

In included shtml file:

<!--#if expr="$D_TBL1" -->
table example<br>
<!--#perl sub="Apache::OverSSI::table" 
    arg = "$D_TBL1" 
    arg = '<table align=center border=1>'
    arg = '<tr><th>C1</th><th>C2</th><th>C3</th><th>C4</th><th>C5</th></tr>'
    arg = '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>'
    arg = '</table>'
-->
table example<br>
<!--#endif -->

=cut

sub table {
    my($r, $id, $header, $colnames, $datafmt, $footer) = @_;

    my $rm = ($r->is_main)?$r:$r->main;
    my $table = $rm->pnotes($id);
    unless (defined($table)) {
	$r->log_error(__PACKAGE__."::table: empty data ($id)");
	return;
    }
    
    return unless (scalar(@$table)); # no data

    $r->content_type("text/html");
    $r->send_http_header();
    $r->print ($header."\n");
    $r->print ($colnames."\n");
    foreach my $row (@$table) {
	$r->print(sprintf $datafmt."\n", @$row );
    }
    $r->print ($footer);
}

#----------------------------------------------------------------------

sub _select {
    my ($r, $table, $value, $datafmt) = @_;

    unless (defined($table)) {
	# log error
	return;
    }
    
    return unless (scalar(@$table)); # no data
#	print STDERR 'REF ',ref \$table->[0], "\n";

    # default value
    $datafmt = "<option value='%s'%s>%s</option>" unless $datafmt;

    my $single=(ref \$table->[0] eq 'SCALAR'); # one column table
    # check if !$single and ref !ARRAY

    $r->content_type("text/html");
    $r->send_http_header();

    foreach my $row (@$table) {
	my ($key, $name);
	if ($single) {
	    $key = $name = $row;
	} else {
	    $key = $row->[0];
	    $name = $row->[1];
	}
	my $sel = ($value eq $key)?' selected':'';
	my $s=sprintf $datafmt."\n", $key, $sel, $name;
	$r->print($s);
    }
}

#----------------------------------------------------------------------

sub select {
    my ($r, $id, $value, $datafmt) = @_;
    my $rm = ($r->is_main)?$r:$r->main;
    my $table = $rm->pnotes($id);
    return _select($r, $table, $value, $datafmt);
}

#----------------------------------------------------------------------

sub selectc {
    my ($r, $id, $value, $datafmt) = @_;

    my $table;
    if ($id eq 'days') {	@$table = map { sprintf "%02i",$_ } (1..31);
    } elsif ($id eq 'months') {	@$table = map { sprintf "%02i",$_ } (1..12);
    } elsif ($id eq 'years-1') {@$table = ( (localtime())[5]+1899, (localtime())[5]+1900);
    } else { 			$table = [];
    }
    return _select($r, $table, $value, $datafmt);
}
#----------------------------------------------------------------------

sub selecti {
    my ($r, $id, $value, $datafmt) = @_;
    
    my @table = split /,/,$id;
    return _select($r, \@table, $value, $datafmt);
}

#----------------------------------------------------------------------

sub replaceval {
    my ($r, $name, $val) = @_;
    
    my $uri = $r->subprocess_env('REQUEST_URI');
    
    if ($uri =~s /(\?|&)$name=(\d+)$/$1$name=$val/) {
    } elsif ($uri =~s /(\?|&)$name=(\d+)&/$1$name=$val&/) {
    } elsif ($uri =~ /&$/) { $uri .= "$name=$val";	# �������� � �����
    } elsif ($uri =~ /\?/) { $uri .= "&$name=$val";	# �������� � �����
    } else { $uri .= "?$name=$val"
    }

    $r->content_type("text/html");
    $r->send_http_header();
    $r->print($uri);
}

#----------------------------------------------------------------------
sub direct_not_found {
    my $r = shift;
    print STDERR "STOP: ".$r->is_main;
    return ($r->is_main)?NOT_FOUND:DECLINED;
}

#----------------------------------------------------------------------

1;


__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: OverSSI.pm,v 1.14 2004/11/25 19:11:56 aleko Exp $

=cut

#######################################################################
