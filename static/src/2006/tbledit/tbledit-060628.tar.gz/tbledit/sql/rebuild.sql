\c jean
\! sleep 1
drop database tbledit;
create database tbledit; 
\c tbledit
\i crebas.sql
\i reload.sql
