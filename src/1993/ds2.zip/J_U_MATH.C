// j__math


 #include "j__const.h"
 #include "j__shell.h"


 #define lver   struct list_vershina
 #define lreb   struct list_rebro
 #define ladreb struct list_adr_rebro
 #define knot   struct list_knots

 lver { float x, y;
        lver *next; };
 lreb { lver *a, *b;
        lreb *next; };
 ladreb { lreb *r;
          ladreb *next; };
 knot { float y;
        lreb *reb;
        knot *left, *right; };

 extern char *dsyms;

 static lver *listver;
 static lreb *listreb;
 static float bymin, bymax;
 static knot *root_tree;


  void prginst(), prglocal(), treeans (knot *rtr );
 int cmpvr ( lver *v,  lreb *r), lefter (lreb *r1, lreb *r2);


 void prginst ()
 { int i, j, cnt;
   char *y;
   float poi[4], yy;
   lreb *reb;
   ladreb *ladr, *ladr1, *ladr2;
   extern void initreb (float mm[]);
   extern knot *trapezium (float ymin, float ymax, ladreb *ladr1);
   status ("��ନ஢���� �������� ������");
   mreadon(dsyms);
   y=mread();  // tittle
   cnt=atoi(y); sfree(y);
   for (i=0; i<cnt; i++)
     { for (j=0; j<4; j++) { y=mread(); poi[j]=atoi(y); sfree(y); }
       initreb(poi);
     }
   reb=listreb;
   ladr1=0;
   while (reb)
       { ladr2=salloc(1,sizeof(ladreb));
         ladr2->r=reb; ladr2->next=0;
         if (!ladr1) { ladr1=ladr2; }
            else ladr->next=ladr2;
         ladr=ladr2;
         reb=reb->next;
       }
   root_tree=trapezium(bymin,bymax,ladr1);
   moutstr(0,0," �।��ࠡ�⪠ : ��ॢ� ���᪠ ����஥��",resatr,resatr);
   moutstr(1,0," ",resatr,resatr);
   treeans(root_tree);
   askpoint(0,&yy,&yy);
   bell();
  }
 void prglocal()
    { lreb *lt,*rt;
      float a,b;
      char *y, *y1;
      extern void treesearch (knot *root_tree,float x, float y,
                              lreb **lt,lreb **rt);
      extern void ansreb (lreb *reb);
      lt=rt=0;
      if (!askpoint(1,&a,&b)) return;
      treesearch (root_tree,a,b,&lt,&rt);
      bell();
      //  out of results
      moutstr(1,0," ���������� �窨 ",vdtatr,resatr);
      y=makeitoa((int) a); if (*y=='0') y1=" 0"; else y1=y;
      moutstr(0,0,y1,vdvatr,resatr); sfree (y);
      moutstr(0,0,"  ",resatr,resatr);
      y=makeitoa((int) b); if (*y=='0') y1=" 0"; else y1=y;
      moutstr(0,0,y1,vdvatr,resatr); sfree (y);
      moutstr(1,0," �����  �࠭�� ->  ",resatr,resatr);
      if (lt) ansreb(lt);
         else moutstr (0,0," ���������...",vdtatr,resatr);
      moutstr(1,0," �ࠢ�� �࠭�� ->  ",resatr,resatr);
      if (rt) ansreb(rt);
         else moutstr (0,0," ���������...",vdtatr,resatr);
    }

  void initreb (float mm[])
     { lver *adrp[2];
       int i,fl;
       lreb *llr, *reb;
       extern lver *initver(float x, float y);
       if (mm[1]==mm[3]) return;
       for (i=0;i<2;i++)
           adrp[i]=initver(mm[2*i],mm[2*i+1]);
       reb=salloc(1,sizeof(lreb));
       if (mm[1]<mm[3]) fl=0; else fl=1;
       reb->a=adrp[fl]; reb->b=adrp[1-fl];
       reb->next=0;
       if (!listreb) { listreb=reb; return; }
       llr=listreb;
       if (llr->a->y<=reb->a->y)
        { if (llr->a->x==reb->a->x && llr->b->x==reb->b->x
             && llr->a->y==reb->a->y && llr->b->y==reb->b->y )
           { sfree(reb); return; }
          reb->next=llr; listreb=reb; return; }
       while (llr->next && llr->next->a->y>reb->a->y ) llr=llr->next;
       while (llr->next && llr->next->a->y==reb->a->y)
           { llr=llr->next;
             if (llr->a->x==reb->a->x && llr->b->x==reb->b->x
             && llr->b->y==reb->b->y ) { sfree(reb); return; }
           }
      reb->next=llr->next;
      llr->next=reb;
  }

 lver *initver(float x, float y)
    { lver *llv,*ver;
      ver=salloc(1,sizeof(lver));
      ver->x=x; ver->y=y; ver->next=0;
      if (!listver) { listver=ver; bymin=bymax=y; return ver; }
      llv=listver;
      if (y<bymin) bymin=y; else if (y>bymax) bymax=y;
      if (llv->y<=ver->y)
         { if (llv->x==ver->x && llv->y==ver->y)
              { sfree(ver); return llv; }
           ver->next=llv; listver=ver; return ver;
         }
       while (llv->next && llv->next->y>ver->y) llv=llv->next;
       if (llv->next)
        { if (llv->next->y==ver->y)
             while (llv->next && llv->next->y==ver->y)
                 { llv=llv->next;
                   if (llv->x==ver->x) { sfree(ver); return llv; }
                 }
        }
      ver->next=llv->next;
      llv->next=ver;
      return ver;
    }

  knot *trapezium (float ymin, float ymax, ladreb *ladr1)
     { ladreb *novladr1, *novladr,
              *ninladr1, *ninladr,
              *ladr, *oldladr, *ninladr2,
              *locadr1, *locadr, *curel;
       int nor, curt;
       float ymed;
       knot **treepnt, *root;
       extern int over (lreb *reb, float y0, float y1);
       extern int intern (lreb *reb, float y0, float y1);
       extern void clearlist (ladreb *adr);
       extern void appreb (lreb *reb, ladreb **adr0);
       extern knot *balance ( knot **pnt, int num);
       extern void initmed (float y0, float y1);
       extern void infomed (lreb *reb);
       extern float getmed ();
       novladr1=0;
       ninladr1=0;
       nor=0;
       ladr=ladr1;
       while (ladr)
           { if (over(ladr->r,ymin,ymax))
              { appreb(ladr->r,&novladr1); nor++; }
              else if (intern(ladr->r,ymin,ymax))
                    { oldladr=salloc(1,sizeof(ladreb));
                      oldladr->r=ladr->r;
                      oldladr->next=0;
                      if (!ninladr1)
                         ninladr1=ninladr=oldladr;
                         else { ninladr->next=oldladr;
                                ninladr=oldladr; }
                    }
             ladr=ladr->next;
           }
//       if (oldladr) { sfree (oldladr->next);
//                      oldladr->next=0; }
       treepnt=salloc(2*nor+1,sizeof(knot *));
       curt=0;
       novladr=novladr1;
       while (novladr)
           { ninladr=ninladr1;
             ninladr2=locadr=locadr1=0;
             initmed (ymin,ymax);
             while (ninladr)
                 { if (lefter (ninladr->r,novladr->r))
                    { // delete
                      curel=ninladr;
                      if (curel==ninladr1)
                         ninladr=ninladr1=ninladr2=ninladr->next;
                         else ninladr=ninladr2->next=ninladr->next;
                      curel->next=0;
                      // append
                      if (!locadr1) locadr1=locadr=curel;
                         else { locadr->next=curel;
                                locadr=curel;
                              }
                      // know ver
                      infomed (locadr->r);
                    } else { ninladr2=ninladr;
                             ninladr=ninladr->next;
                           }
                 }
             ymed=getmed();
             if (ymed!=ymin)
              { root=salloc(1,sizeof(knot));
                root->y=ymed; root->reb=0;
                root->left=trapezium (ymin,ymed,locadr1);
                root->right=trapezium(ymed,ymax,locadr1);
                *(treepnt+curt++)=root;
               clearlist(locadr1);
              }
             root=salloc(1,sizeof(knot));
             root->reb=novladr->r;
             root->y=0;
             root->left=root->right=0;
             *(treepnt+curt++)=root;
             novladr=novladr->next;
           }
       ninladr=ninladr1;
       initmed(ymin,ymax);
       while (ninladr)
           { infomed (ninladr->r);
             ninladr=ninladr->next;
           }
       ymed=getmed();
       if (ymed!=ymin)
        { root=salloc(1,sizeof(knot));
          root->y=ymed; root->reb=0;
          root->left=trapezium (ymin,ymed,ninladr1);
          root->right=trapezium(ymed,ymax,ninladr1);
          *(treepnt+curt++)=root;
        }
       root=balance(treepnt,curt);
       sfree(treepnt);
       clearlist(ninladr1);
       clearlist(novladr1);
       return root;
     }
 int over (lreb *reb, float y0, float y1)
   { if (reb->a->y<=y0 && reb->b->y>=y1) return 1;
        else return 0;
   }
 int intern (lreb *reb, float y0, float y1)
   { if ( (reb->a->y>y0 && reb->a->y<y1) ||
          (reb->b->y>y0 && reb->b->y<y1) ) return 1;
        else return 0;
   }

 void clearlist (ladreb *adr)
    { ladreb *adr1;
      if (!adr) return;
      do { adr1=adr->next;
           sfree (adr);
           adr=adr1;
         } while (adr);
    }

 int cmpvr ( lver *v,  lreb *r)
   { float k,xx;
     if (r->a->x == r->b->x) xx=r->a->x;
      else { k=(r->b->y-r->a->y)/(r->b->x-r->a->x);
             xx=(v->y-r->a->y+k*r->a->x)/k;
           }
     if (v->x<=xx) return 1; else return 0;
   }

 int lefter (lreb *r1, lreb *r2)
   {
     if (r1->a->y>r2->a->y && r1->a->y<r2->b->y) return cmpvr(r1->a,r2);
     if (r1->b->y>r2->a->y && r1->b->y<r2->b->y) return cmpvr(r1->b,r2);
     if (r2->a->y>r1->a->y && r2->a->y<r1->b->y) return !cmpvr(r2->a,r1);
     if (r2->b->y>r1->a->y && r2->b->y<r1->b->y) return !cmpvr(r2->b,r1);
     { float x1, x2;
       if (r1->a->x == r2->a->x) { x1=r1->b->x; x2=r2->b->x; }
          else { x1=r1->a->x; x2=r2->a->x; }
       if (x1<x2) return 1; else return 0;
     }
   }


 void appreb (lreb *reb, ladreb **adr0)
    { ladreb *adr, *adr2, *adr3;
      static ladreb *adr1;
      adr=salloc (1,sizeof(ladreb));
      adr->r=reb;
      adr->next=0;
      adr2=*adr0;
      if (!*adr0) { *adr0=adr1=adr; return; }
      while (!lefter(reb,adr2->r) && adr2->next)
          { adr3=adr2; adr2=adr2->next; }
      if (!lefter(reb,adr2->r))
       { adr1->next=adr;
         adr1=adr;
         adr->next=0;
         return;
       }
      if (adr2==*adr0)
       { adr->next=adr2;
         *adr0=adr;
         return;;
       }
     adr->next=adr3->next;
     adr3->next=adr;
     return;
   }

 knot *balance ( knot **pnt, int num)
    { knot *node;
      int loc;
      if (!num) return 0;
      if (num==1) return *pnt;
      loc=(num-1)/2;
      if (!(*(pnt+loc))->reb) loc ++;
      node=*(pnt+loc);
      if (!node->reb) message (0," error list ");
      node->left=balance(pnt,loc);
      node->right=balance(pnt+loc+1,num-loc-1);
      return node;
    }


//  mediana's  apparatus

 #define lmed struct list_mediana
 lmed { float y;
        lmed *next; };
 static lmed *lm1;
 static float lmy0, lmy1;
 static int lmnum;

 void initmed (float y0, float y1)
    { lmnum=0;
      lmy0=y0; lmy1=y1;
      lm1=salloc(1,sizeof(lmed));
      lm1->y=y0;
      lm1->next=0;
    }

 static void appmed (float y)
      { lmed *lm2, *lm3, *lm4;
        if (lmy0>=y || lmy1<=y) return;
        lm2=lm1;
        while (lm2->y<y && lm2->next)
            { lm3=lm2; lm2=lm2->next; }
        if (lm2->y==y) return;
        lmnum++;
        lm4=salloc(1,sizeof(lmed));
        lm4->y=y;
        if (lm2->y<y) { lm2->next=lm4; lm4->next=0; return; }
        if (lm2==lm1) { lm4->next=lm1; lm1=lm4; return; }
        lm4->next=lm3->next;
        lm3->next=lm4;
      }


 void infomed (lreb *reb)
    { appmed (reb->a->y);
      appmed (reb->b->y);
    }

 float getmed ()
     { float res;
       int i;
       lmed  *lm2;
       lm2=lm1; lmnum=(lmnum+1)/2;
       for (i=0;i<lmnum;i++) lm2=lm2->next;
       if (lm2->next) res=lm2->next->y; else res=lm2->y;
       while (lm1) { lm2=lm1->next;
                     sfree (lm1);
                     lm1=lm2;
                   }
       return res;
     }

   void treesearch (knot *rootree,float x, float y,
                    lreb **lt,lreb **rt)
  { knot *pnt = rootree;
    if (y>bymax || y<bymin) return;
    if (!pnt) return;
    if (!pnt->reb)
       { if (y>pnt->y) treesearch(pnt->right,x,y,lt,rt);
            else treesearch(pnt->left,x,y,lt,rt);
         return;
       }
    { lver *vr= salloc (1,sizeof(lver));
      vr->x=x; vr->y=y;
      if (cmpvr(vr,pnt->reb))
       { *rt=pnt->reb; treesearch(pnt->left,x,y,lt,rt); }
    else { *lt=pnt->reb; treesearch(pnt->right,x,y,lt,rt); }
    }
   }

 void ansreb (lreb *reb)
    { char *y, *y1;
      moutstr (0,0," a:  x>",vdtatr,resatr);
      y=makeitoa((int) reb->a->x);
      if (*y=='0') y1=" 0"; else y1=y;
      moutstr (0,0,y1,vdvatr,resatr); sfree(y);
      moutstr (0,0,"  y>",vdtatr,resatr);
      y=makeitoa((int) reb->a->y);
      if (*y=='0') y1=" 0"; else y1=y;
      moutstr (0,0,y1,vdvatr,resatr); sfree(y);
      moutstr (0,0,"    b:  x>",vdtatr,resatr);
      y=makeitoa((int) reb->b->x);
      if (*y=='0') y1=" 0"; else y1=y;
      moutstr (0,0,y1,vdvatr,resatr); sfree(y);
      moutstr (0,0,"  y>",vdtatr,resatr);
      y=makeitoa((int) reb->b->y);
      if (*y=='0') y1=" 0"; else y1=y;
      moutstr (0,0,y1,vdvatr,resatr); sfree(y);
    }




   void treeans (knot *rtr )
  { knot *pnt = rtr;
    char *y;
    if (!pnt) { moutstr (1,0," ����...  ",vdtatr,resatr); return; }
      if (pnt->reb)
          { moutstr (1,0," ���� : ",vdtatr,resatr);
            ansreb (pnt->reb);
          }
          else { moutstr (1,0," ������� : ",vdtatr,resatr);
                 y=makeitoa((int) pnt->y);
                 moutstr (0,0,y,vdvatr,resatr); sfree(y);
               }
       moutstr (1,0," ����� �����ॢ� : ",vdtatr,resatr);
       treeans(pnt->left);
      if (pnt->reb)
          { moutstr (1,0," *  ���� : ",vdtatr,resatr);
            ansreb (pnt->reb);
          }
          else { moutstr (1,0," * ������� : ",vdtatr,resatr);
                 y=makeitoa((int) pnt->y);
                 moutstr (0,0,y,vdvatr,resatr); sfree(y);
               }
       moutstr (1,0," �ࠢ�� �����ॢ� : ",vdtatr,resatr);
       treeans(pnt->right);
         return;
       }
   void parkdata ()
   { lver *lv, *lv1;
     lreb *lr, *lr1;
     extern void deltree ( knot *rtr);
     deltree(root_tree);
     lr=listreb;
     while (lr)
         { lr1=lr; lr=lr->next;
           sfree (lr1);
         }
     lv=listver;
     while (lv)
         { lv1=lv; lv=lv->next;
           sfree (lv1);
         }
     listver=0;
     listreb=0;
     root_tree=0;
   }
   void deltree ( knot *rtr)
  { knot *pnt = rtr;
      if (!pnt) return;
      if (pnt->reb) sfree (pnt->reb);
      deltree(pnt->left);
      deltree(pnt->right);
      sfree (pnt);
  }

