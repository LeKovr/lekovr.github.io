# $Id: index.pl,v 1.1 2004/08/08 18:46:37 jean Exp $
# USS CGI launcher

# if placed in user directory
#use lib './../dbit/lib';

use CGI::Carp qw(fatalsToBrowser);

use Apache;
use Apache::OverSSI;	# if you want PerlSSI
use Apache::OverSSIApp::DBITable;
return Apache::OverSSIApp::DBITable::handler(Apache->request());

1;
