# Before `make install' is performed this script should be runnable with
# `make test'. After `make install' it should work as `perl test.pl'

#########################

# change 'tests => 1' to 'tests => last_test_to_print';
use FindBin qw($Bin);
use lib "$Bin/lib";

use Test;
BEGIN { plan tests => 2 };
use Apache::OverSSIApp::DBITable;	ok(1);
use Apache::OverSSIApp::DBITableConfig;	ok(1);

