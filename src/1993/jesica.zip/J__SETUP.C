// j__setup

 #include <dos.h>
 #include <stdlib.h>

 char far *vid_mem;

 void oldscreen (char *mode);

 void setup(int own)
 { char *mainhead=
"        ������       �室�� �����       ���᫥���       ���ᠭ��           ";
   char *mainkey="����";
   int mainnum=4;
   oldscreen("off");
   if (!own)
    { printf("\n TOP - 3 / JESICA <by Jean>. Exclusive Unit... \n");
      if (!equalhot(getpass("Your ID password, please >"),"jes"))
       { printf("...bad user."); getch();
         oldscreen("on"); exit(1);
       }
    }
      else sndmode (own);
    install();
    readlib();
    helperinit();
    calcinit();
    saveinit();
    inpinit();
    makescr();
    menulininit (0,0,mainhead,mainkey,mainnum);
    status (" �� (�����) ������ ���� ��襣� �ਪ�᭮����� ");
    melody();
 }


 static int x=0,y,vmd;
 static char *scr;

  void oldscreen (char *mode)
    { union REGS r;
      int vv;
      if (equal(mode,"off"))
         { r.h.ah=15;
           vmd=int86(0x10,&r,&r)&255;
           switch (vmd) {
               case 7  :
               case 3  : x=24; y=79; break;
               default : r.h.ah=0; r.h.al=3;
	                 int86(0x10,&r,&r);
		        }
           if (vmd==7) vid_mem=(char far *)0xB0000000;
		  else vid_mem=(char far *)0xB8000000;
           if (!x) return;
           vv=2*(x+1)*(y+1);
           scr=calloc(vv,sizeof(char));
           if (!scr) {
printf("�� ����, 祬 �� ������ ��, �� ��� � �⮩ ��� ���� ���...\n");
                       exit(1);
                     }
           save_video(0,0,x,y,scr,0);
         }
    else {  // if (vmd!=3) { r.h.ah=0; r.h.al=vmd;
	    //             int86(0x10,&r,&r);
	    //	        }
           if (!x) { clw (0,0,80,25,7); goto_xy(0,0); return; }
           restore_video(0,0,x,y,scr,0);
           free(scr);
         }
  }

