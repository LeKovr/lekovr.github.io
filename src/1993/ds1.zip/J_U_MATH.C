// j__math

 #include "j__const.h"
 #include "j__shell.h"

 extern char *dsyms;

 typedef struct { int a,b; } rebro;



 static  int numreb,numver,cver,creb;
 static  rebro *listreb;
 static char **listver;
 static int sum, *lst;

 static int findver (char *st);
 static int findreb (int a, int b, int addflag);

 void prginst(), prglocal(), parkdata();


void prginst()
 { int i,i1,i2;
   char *a,*b;
   extern void Find();
   status (" �।��ࠡ�⪠");
   mreadon(dsyms);
   a=mread();
   numreb=atoi(a);sfree(a);
   numver=cver=creb=0;
   listreb=salloc(numreb,sizeof(rebro));
   listver=salloc(numreb*2,sizeof(char *));
   for (i=0;i<numreb;i++)
       { a=mread(); b=mread();
	 i1=findver(a); i2=findver(b);
	 findreb(i1,i2,1);
       }
   numver = cver;
   sum=0;
   moutstr(0,0," ",resatr,resatr);
   moutstr(2,4,"������� ���᪠ 横��� :",resatr,resatr);
      lst=salloc(numver+1,sizeof(int));
       for (i=0;i<numver;i++)
           Find (i,-1,i); /* ��ࠡ�⪠ 横��� */
 //      if (sum == 0) printf ("����������.\n");
       moutstr(1,30," ������⢮ 横��� = ",resatr,resatr);
       moutstr(0,0,makeitoa(sum),resatr,resatr);
//	       printf ("       (�室�� � Find -  %d)\n",lsum);
     status (" ");
     sfree(lst);
 }

 void prglocal()
 {
 }

 void parkdata()
 {
   numreb=numver=cver=creb=0;
   sfree (listreb);
   sfree (listver);
   // listver=salloc(numreb*2,sizeof(char *));
   // ��� ������ ���⪨ ���� �ன� �� ���ᠬ �� ᯨ᪠ listver
 }

static void Find (a,b,c) /* ��諨 �� b � c � �饬 ���� � a */
  int a,b,c;
  {   static int *pnt,   /* 㪠��⥫� �� ⥪���� ���設� ���    */
	         tabu; /* ⠡� �� ��室 ������ 横�� ��� ࠧ� */
             int i;
      extern void Ans();
      extern int Not_was();
//      lsum++;
      if (b==-1) {pnt=lst; *pnt=c; tabu=-1;} else *++pnt=c;
      for (i=a;i<numver;i++)
	  if ((i!=b)&&findreb(c,i,0)) /* �᫨ ���� ॡ� � ���設� */
	     { if ((i==a && c>tabu)) { sum++;Ans(pnt);} /* ���� 横� ! */
		  else if (Not_was(pnt,i)) { if (b==-1) tabu=i;
                                             Find (a,c,i);
                                           }
	     }
      pnt--;
  }

static  int Not_was(lim,x) /* ���� ���設� x � ᯨ᪥ */
  int *lim,x;
  {   int *l,y=1;
      for (l=lst;l<=lim;l++) if (*l==x) {y=0; break;};
      return y;
  }
static void Ans (int *lim) /* �뢮� ᯨ᪠ ���騭 横�� */
  {   int *l;
      moutstr(0,20," ",resatr,resatr);
      for (l=lst;l<=lim;l++)
	  { moutstr(0,0,*(listver+*l),resatr,resatr);
	    if (l<lim)
	       moutstr(0,0," - ",resatr,resatr);
	  }
       moutstr(1,0," ",resatr,resatr);
  }

 int findver (char *st)
     { int i;
       if (!cver) { *listver=st; cver=1; return 0; }
       for (i=0;i<cver;i++)
	   { if (!strcmp(*(listver+i),st)) return i;
	   }
       *(listver+cver)=st;
       cver++;
       return cver-1;
     }

 int findreb (int a, int b, int flag)
     { int i;
       if (a>b) { i=b; b=a; a=i; }
       if (!creb) { listreb->a=a; listreb->b=b; creb=1; return 0; }
       for (i=0;i<creb;i++)
	   { if ((listreb+i)->a==a && (listreb+i)->b==b) return 1;
	   }
       if (!flag) return 0;
       (listreb+creb)->a=a;
       (listreb+creb)->b=b;
       creb++;
       return 0;
     }

