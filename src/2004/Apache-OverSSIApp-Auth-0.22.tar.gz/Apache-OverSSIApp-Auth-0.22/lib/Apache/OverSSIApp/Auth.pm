package Apache::OverSSIApp::Auth;

# $Id: Auth.pm,v 1.9 2004/08/24 18:18:39 aleko Exp $

=head1 NAME

Apache::OverSSIApp::Auth - User Authorization module

=head1 DESCRIPTION

Apache::OverSSIApp::Auth is a simple utility allowing users to
login/register/change_password/restore_password/logout via SQL.
based on Apache::OverSSI library

=over 4

=cut
    
use strict;
use warnings;

use base qw(Apache::OverSSI::Request);

use Fcntl qw(:flock);
use Apache::Constants qw(:common);
use Apache::Session::Flex;
use Params::Validate qw(:all);

use Apache::OverSSI 0.21;
use Apache::OverSSI::Server;
use Apache::OverSSI::Command;
use Apache::OverSSI::Utils;
use Apache::OverSSI::Exception;
use Apache::OverSSI::DBI;

use Apache::OverSSIApp::AuthConfig;

our $VERSION = '0.22';
our $REVISION = sprintf("%d.%02d", '$Revision: 1.9 $' =~ /(\d+)\.(\d+)/);

my $srv; # ������������ ��� ���� ������:���������� ������ � ����������� ����������

BEGIN {

    $srv = Apache::OverSSI::Server->new(
	# Module name for logging & global variables
	module_name => 'Auth',
    
	# Default command name
	default_command	=> 'login',
	
    );

    # commands: [subrequest, 0(user)|1(part)|2(topic), perm tag, pointer]
    $srv->command('fetch',     Apache::OverSSI::Command->new( func=> \&do_fetch, subr => 1 ) );
    $srv->command('check',     Apache::OverSSI::Command->new( func=> \&do_check, subr => 1 ) );
    $srv->command('login',     Apache::OverSSI::Command->new( func=> \&do_login ) );
    $srv->command('logout',    Apache::OverSSI::Command->new( func=> \&do_logout ) );
    $srv->command('register',  Apache::OverSSI::Command->new( func=> \&do_logout ) );
    $srv->command('newpass',   Apache::OverSSI::Command->new( func=> \&do_logout ) );
    $srv->command('restore',   Apache::OverSSI::Command->new( func=> \&do_logout ) );

    __PACKAGE__->valid_params (
	f_select => {
    	    type => ARRAYREF, default => [],
	    descr => "Per request storage for form select" 
	 },
	f_table => {
    	    type => ARRAYREF, default => [],
	    descr => "Per request storage for form table" 
	 },
    );

}

use Apache::OverSSI::MethodMaker (
    read_write => [ 
	keys %{__PACKAGE__->validation_spec}
    ],
);


#----------------------------------------------------------------------

=item handler

Main procedure. Initializes variables and calls
requested command

=cut

sub handler {
    my $r = shift;
    my $rec = __PACKAGE__->new(server => $srv, request => $r);
    my @config = $rec->load_conf(keys %{Apache::OverSSIApp::AuthConfig->validation_spec})
	or return NOT_FOUND;
    return $rec->run( Apache::OverSSIApp::AuthConfig->new(@config) );
    
}

#----------------------------------------------------------------------
# login
# ACL: User

sub _check_args {
    my $self = shift;
    my $p = shift;

    my $args = $self->args;
    my @a;
    foreach my $key (qw(id auth)) {
	my $value = $self->param($key);
	push @a, ($key, $value) if defined($value);
    }

    return undef unless (scalar(@a)); # repeat login form
    eval {
	%{$p} = validate( @a, { 
	    id =>	{ type => SCALAR, untaint => 1, regex => qr/^\w+$/ , },
	    auth =>	{ type => SCALAR, untaint => 1, regex => qr/^\w+$/ ,     default => '' },
	} );
    };

    if ($@) {
	$p->{'_error'} = $@;
	return undef;
    }
    return 1;
}


sub do_login {
    my $self = shift;

    my %p;
    unless ( $self->_check_args(\%p) ) {
	if (exists($p{'_error'}) ) {
	    $self->print_log(3, "Args validation errors: $p{'_error'}");
	    return 11;
	} else {
	    return 1;
	}
    }
    my $auth = $p{'auth'};
    delete $p{'auth'};
    $self->args(\%p);

    #----------------------------------------------------------------------
    # ���������� � ��
    my $dbh = db_connect($self->config);
    #----------------------------------------------------------------------
    my $data = $dbh->selectrow_hashref($self->config->sql, undef, $p{'id'}) or
	Exception->throw(code=>'11', info => $DBI::errstr || "Unknown user $p{'id'}"); # unless defined($data);
    
    my $fld = $self->config->auth_field;

    my $pass;
    if ( $self->config->use_crypt ) {
	my $salt = substr $data->{$fld}, 0, 2;
	$pass = crypt($auth, $salt);
    } else {
	$pass = $auth;
    }
    if ( $pass ne $data->{$fld} ) {
	$self->print_log(3, "Attempt to login as $p{'id'} with bad password $auth");
        return 12;
    }

    my $session = $self->session();

    $session->{'_logged'} = $session->{'_lastactive'} = $self->stamp;
    $session->{'_state'}  = 3; # just logged in;
    
    foreach my $key (keys %$data) {
	$session->{$key} = $data->{$key} if ($key ne $fld);
	$self->print_log(9, "SESSION{$key}=$data->{$key}");
    }
    return $self->redirect($self->config->session_logon);
    
}


#----------------------------------------------------------------------
# check
# ACL: subrequest only
# Req: check?id=ID&auth=AUTH
# check if arguments data conforms login & fill ENV

sub do_check {
    my $self = shift;

    my $session = $self->session();

    if (defined($session->{'_logged'})) {
	#authorized
	$self->store_vars($self->r_main, $session);
	$session->{'_lastactive'} = $self->stamp;
	$session->{'_state'}  = 2; # logged in;
    } elsif ( $session->{'_state'} and $session->{'_state'} == 1 ) {
	#just logged out
	#$self->store_vars($self->r_main, { '_state' => 1 } );
	$self->store_vars($self->r_main, $session);
	$session->{'_state'} = 0; # guest;
    }
    return undef;
}


#----------------------------------------------------------------------
# fetch
# ACL: subrequest only
# fill env with session data if present

sub do_fetch {
    my $self = shift;

    my $session = $self->session();

    if (defined($session->{'_logged'})) {
	#authorized
	$self->store_vars($self->r_main, $session);
	$session->{'_lastactive'} = $self->stamp;
	$session->{'_state'}  = 2; # logged in;
    } elsif ( $session->{'_state'} and $session->{'_state'} == 1 ) {
	#just logged out
	#$self->store_vars($self->r_main, { '_state' => 1 } );
	$self->store_vars($self->r_main, $session);
	$session->{'_state'} = 0; # guest;
    }
    return undef;
}


#----------------------------------------------------------------------
# logout
# ACL: User

sub do_logout {
    my $self = shift;

    my $s = $self->server;
    my $session = $self->session();

    # tied(%session)->delete;
    $session->{'_logged'} = undef;
    $session->{'_lastactive'} = $self->stamp;
    $session->{'_state'}  = 1; # just logged out

    return $self->redirect($self->config->session_logout);
}

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: Auth.pm,v 1.9 2004/08/24 18:18:39 aleko Exp $

=cut

#######################################################################
