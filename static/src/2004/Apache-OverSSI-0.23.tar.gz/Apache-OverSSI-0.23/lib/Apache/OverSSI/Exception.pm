package Apache::OverSSI::Exception;

# $Id: Exception.pm,v 1.2 2004/08/08 19:14:28 jean Exp $

=head1 NAME

Apache::OverSSI::Command - class for application commands

=head1 DESCRIPTION

Apache::OverSSI is a library for lightweight mod_perl
applications which use SSI for output templating.
based on Apache, mod_perl, mod_include and mod_env.

=over 4

=cut

use strict;
use warnings;
use Carp;

use Exporter;
our @ISA        = qw(Exporter);
our @EXPORT = qw(Exception);

use constant Exception => 'Apache_OverSSI_Exception_Object';

use Exception::Class( &Exception => { fields => [ qw(code info)] } );

#----------------------------------------------------------------------

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: Exception.pm,v 1.2 2004/08/08 19:14:28 jean Exp $

=cut

#######################################################################
