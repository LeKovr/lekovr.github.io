package Apache::OverSSI::Server;

# $Id: Server.pm,v 1.7 2004/08/08 19:14:28 jean Exp $

=head1 NAME

Apache::OverSSI - mod_perl application library based on SSI templating

=head1 DESCRIPTION

Apache::OverSSI is a library for lightweight mod_perl
applications which use SSI for output templating.
based on Apache, mod_perl, mod_include and mod_env.

=over 4

=cut
    
use strict;
use warnings;
use Params::Validate qw(:all);

use Class::Container;
use base qw(Class::Container);

our $VERSION = sprintf("%d.%02d", '$Revision: 1.7 $' =~ /(\d+)\.(\d+)/);

BEGIN {
    # Fields that can be set in new method, with defaults
    __PACKAGE__->valid_params (
	module_name => {
    	    type => SCALAR,
	    descr => "Prefix for logging and for _CONFIG from httpd.conf" 
	},
        request_params => {
    	    type => HASHREF, default => { POST_MAX => 1024, DISABLE_UPLOADS => 1},
	    descr => "Attributes for Apache::Request object" 
	},
	cmd_param => {
    	    type => SCALAR | UNDEF, default => undef,
	    descr => "Get command from this request parameter or from r->path_info if undef. (requires Options + MultiViews)"
	},
	sid_param => {
    	    type => SCALAR | UNDEF, default => undef,
	    descr => "Get session id this request parameter or from r->notes('cookie') if undef. (requires mod_usertrack)"
	},
	default_command => {
    	    type => SCALAR | UNDEF,
	    descr => "Default command name. error 505 will be returned otherwise If undef"
	},
	use_unique_id => {
	    type => BOOLEAN, default => 1, 
    	    descr => "mod_unique_id usage allowed" 
	},
    );
}

use Apache::OverSSI::MethodMaker (

    read_only => [ 
	keys %{__PACKAGE__->validation_spec}
    ],
);

use Apache::OverSSI::Exception;

#----------------------------------------------------------------------

sub new {
    my $class = shift;

    my $self = $class->SUPER::new(@_);

    $self->_initialize;
    return $self;
}

#----------------------------------------------------------------------

sub _initialize {
    my $self = shift;
    
    $self->{'_command'}={};
    
}

#----------------------------------------------------------------------

sub command {
    my $self = shift;
    my $cmd = shift;
    my $obj = shift;
    if (defined ($obj)) {
	# set
	$self->{'_command'}{$cmd} = $obj;
    } elsif (! exists($self->{'_command'}{$cmd})) {
	#Log error: Unknown cmd
	Exception->throw( code => 33, info => $cmd );
    }
    return $self->{'_command'}{$cmd};
}

1;


__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: Server.pm,v 1.7 2004/08/08 19:14:28 jean Exp $

=cut

#######################################################################
