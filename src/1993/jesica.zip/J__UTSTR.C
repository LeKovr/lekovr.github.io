// j__utstr


 #include <string.h>
 #include <stdio.h>
 #include <math.h>

 extern char *flname;
 char keytohot (char a);
 char *makestr (char *a,char *b);
 char *makeitoa (int i);
 char *makeftoa (float i);
 int is_in (char *s,char c), equal (char *a, char *b);
 int equalhot (char *a, char *b);
 char *makefln (int i);
 char *makenote(int i, char *note);

static char *kbh[] = { "QWERTYUIOP[]ASDFGHJKL;'ZXCVBNM,.",
		       "qwertyuiop[]asdfghjkl;'zxcvbnm",
		       "��������������������������������",
		       "��㪥�������뢠�஫�����ᬨ���" };

 char keytohot (char a)
    { int i,j;
      for (i=0;i<4;i++)
	  if (j=is_in(kbh[i],a)) return *(kbh[0]+j-1);
      return a;
    }

 char *makestr (char *a,char *b)
  { char *c,*c1,*c2;
   int i;
     i=strlen(a)+strlen(b);
     c=c1=salloc(i+1,sizeof(char));c2=a;
     while (i) {*c1++=*c2++; if (*c2=='\0') c2=b; i--;}
     *c1='\0';
    return c;
  }
 int is_in (char *s,char c)
      { register int i;
	int j;
	j=strlen(s);
	for (i=0;i<j;i++) if (*(s+i)==c) return i+1;
	return 0;
      }
  char *makeitoa (int i)
     { int j=1,k;
       char *p,*p1;
       k=i;
       while (i/10) { j++; i/=10; }
       p=p1=salloc(j+1,sizeof(char));
       p1+=j; *p1--='\0';
       for (;j;j--,p1--) { *p1=k%10+'0'; k/=10; }
       return p;
    }

 char *makeftoa (float x)
    { float y=1.0, z;
      int r1,r2;
      char *a, *b, *c, *d;
      if (x<0) { d="-"; x*=-1; } else d=" ";
      z=fmod(x,y);
      r1=x-z;
      r2=z*1000;
      b=makeitoa(r1);
      c=makestr(d,b);
      a=makestr(c,".");
      sfree(b); sfree(c);
      b=makeitoa(r2);
      c=makestr(a,b);
      sfree(a);
      sfree(b);
      return c;
    }

  int equal (char *a, char *b)
      { int i,j;
       i=strlen(a); j=strlen(b);
       if (i!=j) return 0;
       for (i=0;i<j;a++,b++,i++)
	   if (*a!=*b) return 0;
       return 1;
   //   if (strcmp(a,b)==0) return 1; else 0;
      }
  int equalhot (char *a, char *b)
      { int i,j;
       i=strlen(a); j=strlen(b);
       if (i!=j) return 0;
       for (i=0;i<j;a++,b++,i++)
	   if (keytohot(*a)!=keytohot(*b)) return 0;
       return 1;
      }

  char *makefln (int i)
  { char *a,*b,*c;
    a=makeitoa(i);
    b=makestr(flname,".d");
    c=makestr(b,a);
    sfree (a); sfree (b);
    return c;
  }

 char *makenote(int i, char *note)
  { char *a, *b;
    a=makeitoa(i);
    b=makestr(a," "); sfree(a);
    a=makestr(b,note); sfree (b);
    b=makestr(a,"\n"); sfree (a);
    return b;
  }
