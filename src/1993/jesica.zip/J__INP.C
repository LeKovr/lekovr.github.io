// j__inp

 #include <fcntl.h>
 #include <io.h>
 #include "j__const.h"
 #include "j__shell.h"

 extern char far *vid_mem;
 extern point dwin,vwin;
 extern char *flname, *dsyms, **datlib;
 extern int  loc_flag, change_flag, step2_flag;
 extern int  dstatelem, dstatrow;
 extern int  ddynelem, ddynrow;
 extern int  dsymnum, limdblk;
 extern line *dstatblk, *ddynblk;
 extern vars *dstatvars, *ddynvars;
 extern int numlib;
 extern menuptr *dinpmnu;
 extern char *main_flags;
 extern char *save_flags;

 static menuptr *inp0mnu;
 static char *loclib[1]={ kbd };

 list *darea0, *darea1;
 int dmrow, dblknum;


 input();

 void inpinit()
 { inp0mnu=menustatinit(loclib,"�",1,1,21,1,1);
 }

 input()
 { int i,j=1;
   extern void  inpmem(), restvar();
   extern int  inpmenu(), into(), inpload();
   extern char *inpdata();
   do { i=inpmenu();
	switch (i) {
	       case -2 : return 1;
	       case -3 : return -1;
	       case -1 : return 0;
	       case  0 : j=1; break;
	       default : j=inpload(i);
	       }
      } while (!j);
   drawbord(dwin.x-1,dwin.y-1,dwin.x+dwrow,dwin.y+dwcol,
            2,"  �����  ",10,brdatr|INTENSE);
   if (change_flag) { inpmem();
		      clw (vwin.x,vwin.y,vwcol,vwrow,vstatr);
		    }
    i=dsymnum;
   if (into())
      { char *l; int ll;
	l=inpdata();
        ll=equal(dsyms,l);
	if (i!=dsymnum || !ll)
	   { if (step2_flag) sfree(dsyms);
             dsyms=l; change_flag=1;
	   }
      }
      else { dsymnum=i; restvar(); }
      if (change_flag)  clw (vwin.x,vwin.y,vwcol,vwrow,vstatr);

      sfree (main_flags);
      if (change_flag)
         { sfree (save_flags);
           save_flags="1100";
         }
      step2_flag=1;
      main_flags="1111";
   drawbord(dwin.x-1,dwin.y-1,dwin.x+dwrow,dwin.y+dwcol,
            2,"  �����  ",10,brdatr);
      return 1;
 }

 inpmenu ()
 { int i;
   if (numlib) { status ("�롥�� ���筨� �室��� ������");
                 i=menudynact (datlib,dinpmnu);
	       }
       else    { char *locnot[] = {
       "� ������⥪� �室��� ������ ��� 䠩���" };
		 i=menustatact(loclib,locnot,"1",inp0mnu);
		 status (" "); return i;
	        }
 }

 inpload (i)
 int i;
 { int f,j;
   int num;
   long ln;
   char *s, *p, *p1,*r0;
   p1=makefln(i);
   if ((f=_open(p1,O_RDONLY))==-1)
      { s=makestr("�訡�� �⥭�� 䠩�� �室��� ������  ",p1);
	message (0,s); sfree(p1); sfree(s); return 0;
      }
   status ("�⥭�� ������ �� 䠩��");
   ln=filelength(f); sfree(p1);
   if (step2_flag)
      { sfree (dsyms);
	clmem(darea0,dmrow);
        dmrow=0; dblknum=0;
      }
   dsyms=p=salloc(ln,sizeof(char));
   _read(f,p,(unsigned int) ln);
   _close(f); change_flag=1;
   dsymnum=0;
   for (i=0;i<ln;i++,p++) if (*p==DELIM) dsymnum ++;
			  else if (*p=='\n') *p='\0';
   status (" ");
   if (!dsymnum) { message (0,"���� �室��� ������ �� ᮮ⢥����� �ଠ��");
                   return 0;
                 }
   return 1;
 }

 static  void inpmem()
 {  list *d;
    char *loc;
    int  k;
  loc = dsyms;
  if (ddynelem) k=(dsymnum-dstatelem)/ddynelem;
     else k=0;
  if ((dstatelem+k*ddynelem)!=dsymnum)
  { message (1,"JES: SoftWare error #1 ");}
  if (dstatrow) { getblock(&darea0,&darea1,dstatrow);
		  writeblock(dstatblk,dstatvars,&loc,dstatrow,dwcol,
				      dstatelem,darea0,maskatr);
		  dblknum=1; dmrow=dstatrow;
		}
	  else  { getblock(&darea0,&darea1,ddynrow);
		  writeblock(ddynblk,ddynvars,&loc,ddynrow,dwcol,
				      ddynelem,darea0,maskatr);
		  dblknum=1; dmrow=ddynrow; k--;
		}
  while (k)
	{ d=darea1;
	  getblock(&d->next,&darea1,ddynrow);
	  writeblock(ddynblk,ddynvars,&loc,ddynrow,dwcol,
				      ddynelem,(*d).next,maskatr);
	  dblknum++ ;dmrow+=ddynrow;k--;
	}
   status (" ");
}

 static void restvar()
 { int i;
   clmem(darea0,dmrow);
   dmrow=dblknum=0;
   inpmem();
   clw (dwin.x,dwin.y,dwcol,dwrow,dstatr);
   i=dwrow; if (dmrow<dwrow) i=dmrow;
   outwin(dwin.x,dwin.y,i,dwcol,darea0);
 }  // restvar

static   char *inpdata()
  { extern void getvars( char **ls,
			  int offset,
			  int num,
			  int *lens,
			  vars *cv,
			  list *mem);
    int i,off,lens;
    list *adr;
    char **locsym, **p, *pnt0, *pnt1;
   p=locsym=salloc(dsymnum,sizeof(char *));
      adr=darea0; off=lens=0;
      if (dstatelem) { getvars (p,off,dstatelem,&lens,dstatvars,adr);
		       off+=dstatelem;
		       adr=(adr+dstatrow-1)->next;
		     }
      while (off<dsymnum) { getvars (p,off,ddynelem,&lens,ddynvars,adr);
			    off+=ddynelem;
			    adr=(adr+ddynrow-1)->next;
			  }
     pnt0=pnt1=salloc(lens+1,sizeof(char));
     *(pnt0+lens)='\0';
     for (off=0;off<dsymnum;off++)
	 { lens=strlen(*(p+off));
	   for (i=0;i<lens;i++) *pnt1++=*((*(p+off))+i);
	   sfree (*(p+off));
	 }
   sfree(p);
   return pnt0;
 }
  void getvars( char **ls,
	       int offset,
	       int num,
	       int *lens,
	       vars *cv,
	       list *mem)
    { int i=0,j0,j1;
      vars v;
      char *l,kk=maskatr;
      while (num-i)
	    { j0=0; v=*(cv+i); j1=v.len;
	      while (j1)
		    if ((*(mem+v.x)).dat[v.y+j0].at!=kk) break;
		       else { j1--; j0++; }
	      l=*(ls+offset+i)=salloc(j1+2,sizeof(char));
//              if (!j1 && (v.type==2 || v.type=4)) // ���� ���� 㤠����
      *(l+j1)=DELIM, *(l+j1+1)='\0';
	      j0=v.len-j1+v.y; (*lens)+=j1+1;
	      while (j1) { j1--; *(l+j1)=(*(mem+v.x)).dat[j0+j1].ch; }
	      i++;
	    }
   }

static  int cblk,crow,celem,drow,vrow,line1,row,elem,newel_flag,vlen,catr;
static  vars *cvar;
static  list *cadr;

static  int into ()
  { int i,app_mem, lpx;
    extern void appdigit();
    extern int  enter (), pointinit();
  clw (dwin.x,dwin.y,dwcol,dwrow,dstatr);
  status ("������� ��� ���⢥न� �室�� �����");
  i=dwrow; if (dmrow<dwrow) i=dmrow;
  app_mem=limdblk;
  outwin(dwin.x,dwin.y,i,dwcol,darea0);
  if (dstatrow) { cvar=dstatvars; row=dstatrow; elem=dstatelem;catr=dsvatr; }
	   else { cvar=ddynvars; row=ddynrow; elem=ddynelem; catr=ddvatr; }
  line1=cblk=celem=0;newel_flag=1;
  crow=drow=vrow=(*cvar).x; // 0..
  cadr=darea0+drow; vlen=(*cvar).len;
 do {
  do { goto_xy(dwin.x+vrow,dwin.y+(*cvar).y+vlen-1);
       switch (cvar->type) {
	  case 1 : status ("����室��� ����� 楫�� �᫮"); break;
	  case 2 : status ("����室��� ����� ࠧ��୮���"); break;
	  case 3 : status ("����� ����� 楫�� �᫮     "); break;
	  case 4 : status ("����室��� ����� ��ப�     "); break;
	  case 5 : status ("����� ����� ��ப�          ");
			   }
       bottom ("         Esc - ��室             Navi - �����");
       i=getsym();
       switch(i) {
	    case KTab    :
	    case KCRight :
	    case KEnter  : if (pointinit(1)==-1) i=501; break;
	    case KCDown  : lpx=drow;
                           while (drow==lpx)
		           { goto_xy(dwin.x+vrow,dwin.y+cvar->y+vlen-1);
		             if (pointinit(1)<1) break;
		           }
		           break;
	    case KCUp    : lpx=drow;
                           while (drow==lpx)
		           { goto_xy(dwin.x+vrow,dwin.y+cvar->y+vlen-1);
		             if (pointinit(0)<1) break;
		           }
		           break;
	    case KCLeft  :
	    case KSTab   : pointinit(0); break;
	    case KDel    : appdigit(KDel); break;
	    case KEsc    : break;
	    case KHome   : while ( cblk || celem )
		           { goto_xy(dwin.x+vrow,dwin.y+(*cvar).y+vlen-1);
		             if (!pointinit(0)) break;
		           }
                           break;
	    case KEnd    : while (((cblk+1)!=dblknum || (celem+1)!=elem))
		           { goto_xy(dwin.x+vrow,dwin.y+(*cvar).y+vlen-1);
		             if (pointinit(1)<1) break;
		           }
		           break;
	    default      : if (i<257) appdigit(i);        // char
	  }
  if (i==KEsc) { status ("�� ����� �������...");
                i=askbin (1,"��������� ���� ����� ?",0,1);
                if (i==1) return 0;
              }
     } while (i!=0);
   if (limdblk>app_mem)
      { status ("�஢�ઠ ���४⭮�� ��������� ������");
	while (((cblk+1)!=dblknum || (celem+1)!=elem)&&!i )
	      { goto_xy(dwin.x+vrow,dwin.y+(*cvar).y+vlen-1);
		if (pointinit(1)<1) i=1;
	      }
      }
 }  while (i);
   status (" ");
  return 1;
 }
static void appdigit(i)
 int i;
 { int t, k, j, bat, bat1;
   static char far *v;
   char far *tt, b, b1;
   if (i<KSpace) return;
   t=(*cvar).type;
   if (i!=KDel && i!=KSpace && t<4 && (i<'0' || i>'9')) return;
   if (newel_flag) { v=vid_mem+(dwin.x+vrow)*160+(dwin.y+(*cvar).y)*2;
		     newel_flag=0;appdigit(KSpace);
		   }
   tt=v;b1=VMASK ;k=(*cvar).y;  bat1=maskatr;
   if (i!=KDel && i!=KSpace && ((*cadr).dat[k].at-bat1)) return;
   for (j=0;j<vlen;j++)
       { switch (i) {
	      case KSpace : b=b1; bat=bat1; break;
	      case KDel   : b=b1; b1=(*(cadr)).dat[j+k].ch;
			    bat=bat1; bat1=(*(cadr)).dat[j+k].at;
			    break;
	      default     : if (j==(vlen-1)) { b=i; bat=catr; }
			       else { b=(*cadr).dat[j+k+1].ch;
			              bat=(*cadr).dat[j+k+1].at;
				    }
			    break;
		    }
	 (*cadr).dat[j+k].ch=b;
	 (*cadr).dat[j+k].at=bat;
	 *tt++=b; *tt++=bat;
       }
   }
static  int enter()
  { int k,l,len,i;
    char *p,*p1;
    list *d,*d2;
    k=(*cvar).y; l=0; i=maskatr;
    for (l=0;l<vlen;l++)
	 if ((*cadr).dat[k+l].at-i) break;
    if (l==vlen) { switch ((*cvar).type) {
		     case 3 :
		     case 5 : return 1;
		     }
		   message (1,"�� ���� ��易⥫쭮 ��� ����� !");
		   return 0;
		 }
    if ((*cvar).type != 2 ) return 1;
    p=p1=salloc(vlen-l+1,sizeof(char));
    for (;l<vlen;l++) *p1++=(*cadr).dat[k+l].ch;
    *p1='\0'; l=atoi(p); sfree(p);
    if (!l) { message (1,"������ ���� ������⥫�o� ���祭�� !");
	      return 0;
	    }
    if (l==limdblk) return 1;
    if (l>limdblk) { // ���� �� � ������
		     k=l-limdblk;
		     while (k)
			      { d=darea1;
				getblock(&(*d).next,&darea1,ddynrow);
				writeblock(ddynblk,ddynvars,0,
					 ddynrow,dwcol,ddynelem,(*d).next,
                                         maskatr);
				dblknum++ ;dmrow+=ddynrow;k--;
				dsymnum+=ddynelem;
			      }
		   }
	      else { // 㤠���� � ������
		     k=l*ddynrow+dstatrow-1; d=darea0;
		     for (i=0;i<k;i++,d=(*d).next);
		     darea1=d; d=(*d).next; k=limdblk-l;
		     while (k) { d2=d; d=(*(d+ddynrow-1)).next;
				 sfree(d2); dblknum--;
				 dmrow-=ddynrow;
				 dsymnum-=ddynelem;
				 k--;
			       }
		   }
    if (vrow+1==dmrow) return 1;
    i=dwrow-vrow; k=drow+i;
    if (l<limdblk) clw (dwin.x+vrow,dwin.y,dwcol,i,dstatr);
    if (dmrow<k) i=dmrow-drow;
    limdblk=l;
    outwin (dwin.x+vrow,dwin.y,i,dwcol,cadr);
    return 1;
}
static int pointinit (mode)
  int mode;
  { int j;
    list *d;
    if (!enter()) return 0;
    if (mode)
       { if (celem<elem-1)
	    { j=(cvar+1)->x-cvar->x;
	      curdn (j,dwin.x,dwin.y,dwcol,dwrow,dmrow,darea0,
			    &line1,&vrow,&drow,ddtatr);
	      celem++;cvar++;cadr+=j;
	      crow=(*cvar).x;vlen=(*cvar).len;
	    }
       else { if (cblk+1<dblknum)
		 { j=row-crow+(*ddynvars).x;cadr+=(row-crow-1);
		   curdn (j,dwin.x,dwin.y,dwcol,dwrow,dmrow,darea0,
				 &line1,&vrow,&drow,ddtatr);
		   if (cblk==0 && dstatrow)
		      {  row=ddynrow; elem=ddynelem; catr=ddvatr;}
		   celem=0; cvar=ddynvars;
		      cadr=(*cadr).next;cblk++;
		   crow=(*cvar).x;vlen=(*cvar).len; cadr+=crow;
		 }
	    else { if (!ddynrow || limdblk) return -1;
		   d=darea1;
	  getblock(&(*d).next,&darea1,ddynrow);
	       writeblock(ddynblk,ddynvars,0,ddynrow,dwcol,
                          ddynelem,(*d).next,maskatr);
	       dblknum++;dmrow+=ddynrow;dsymnum+=ddynelem;
	       j=row-crow+(*ddynvars).x; cadr=cadr+=(row-crow-1);
	       if (vrow+1<dwrow) outwin(dwin.x+vrow,dwin.y,dwrow-vrow-1,
					dwcol,cadr);
	       curdn (j,dwin.x,dwin.y,dwcol,dwrow,dmrow,darea0,
			     &line1,&vrow,&drow,ddtatr);
	       if (cblk==0 && dstatrow)
		  {  row=ddynrow; elem=ddynelem; catr=ddvatr; }
	       celem=0; cvar=ddynvars; crow=cvar->x;
	       cadr=(*cadr).next; cadr+=crow;  cblk++;
	       if (vrow<dwrow-1) outwin(dwin.x+vrow,dwin.y,ddynrow,
					dwcol,cadr);
	       crow=(*cvar).x;vlen=(*cvar).len;
	     }
       }
   }
   else {
	  if (celem)
	     { j=(*cvar).x-(*(cvar-1)).x;
	       curup (j,dwin.x,dwin.y,dwcol,dwrow,darea0,
			     &line1,&vrow,&drow,ddtatr);
		       celem--;cvar--;cadr-=j;
	       crow=(*cvar).x; vlen=(*cvar).len;
	     }
	else { if (!cblk) return 0;
	       if (cblk==1 && dstatrow)
		  { cvar=dstatvars; row=dstatrow;
		    elem=dstatelem; catr=dsvatr; }
		  else cvar=ddynvars;
	       cvar+=elem-1;
	       j=crow+row-(*(cvar)).x;
	       curup (j,dwin.x,dwin.y,dwcol,dwrow,darea0,
			     &line1,&vrow,&drow,ddtatr);
	       celem=elem-1; cadr= darea0;
	       crow=(*cvar).x; vlen=(*cvar).len;       cblk--;
	       for (mode=0;mode<drow;mode++) cadr =(*cadr).next;
	     }
	}
     newel_flag=1;
     return 1;
  }

