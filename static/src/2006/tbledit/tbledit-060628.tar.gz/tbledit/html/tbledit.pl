#!/usr/bin/perl 
# $Id: tbledit.pl,v 1.2 2006/06/26 19:29:12 jean Exp $
# CGI launcher

use strict;
use warnings;

use CGI::Carp qw(fatalsToBrowser);
use Data::Dumper;

our $VERSION = '0.10';
our $REVISION = sprintf("%d.%02d", '$Revision: 1.2 $' =~ /(\d+)\.(\d+)/);

# -----------------------------------------------------------------------------

use constant CONFIG_PREFIX => 'TBLEDIT_';
use constant  CONFIG => qw(SQL SQL_INIT);
use constant MODES =>
{
  index => \&doIndex,
  view   => \&doView,
  edit   => \&doEdit,
  save   => \&doSave,
  ins   => \&doIns,
  del   => \&doDel,
};

# -----------------------------------------------------------------------------

my $_ROOT; 
BEGIN
{
  require File::Basename; 
  require Cwd; 
  for (my ($d, $i) = (File::Basename::dirname($0), 0); $i < 100; $d .= "/..", $i++) 
  { print STDERR "Check for $d\n";
    if (-e "$d/.is_root") 
    { 
      $_ROOT = Cwd::abs_path($d); 
      last; 
    } 
  } 
  push @INC, $_ROOT . '/lib/'; 
}

# -----------------------------------------------------------------------------

use TblEdit::Request qw(/^LL_/);
use TblEdit::Template;
use TblEdit::DB;
use TblEdit;

# -----------------------------------------------------------------------------

my $req = TblEdit::Request->new({ prefix => CONFIG_PREFIX});
$req->print_log(LL_CMD,'********* TblEdit start *********');

my $conf = $req->get_conf(CONFIG);

my $dbconf = $req->get_conf(TblEdit::DB::CONFIG);
my $db = TblEdit::DB->new({%$dbconf});
$db->do($conf->{'SQL_INIT'}) if $conf->{'SQL_INIT'};

my $server = TblEdit->new({ db => $db, req => $req});

my $tableConfig = $db->hash($conf->{'SQL'});
$server->init
(
  $tableConfig,
  $db->array_hash($tableConfig->{'fields_sql'})
);


$conf = $server->getConf(TblEdit::Template::CONFIG);
print STDERR 'TemplateConfig:',Dumper($conf);
my $template = TblEdit::Template->new($_ROOT, %$conf);

my $opMode = $req->param('op') || 'index';
$opMode = 'index' unless exists MODES->{$opMode};
$req->print_log(LL_VAR, 'Command: ', $opMode);

my $ret =
{
  URL => $req->uri,
  TITLE => $server->conf('table_title')
};

my $tag = (MODES->{$opMode})->($server, $ret);
$req->print($template->run($tag, $ret));

$req->print_log(LL_CMD,'********* TblEdit stop *********');

exit;


sub doIndex
{
  my $self = shift;
  my $ret = shift;
  $self->getTable($ret);
  return 'tmpl_table';
}

sub doView
{
  my $self = shift;
  my $ret = shift;
  $self->getRow($ret, 0);
  return 'tmpl_row';
}

sub doEdit
{
  my $self = shift;
  my $ret = shift;
  $self->getRow($ret, 1);
  return 'tmpl_row_edit';
}

sub doSave
{
  my $self = shift;
  my $ret = shift;
  my $ret1 = {};
  if ( $self->saveRow($ret1) )
  {
    # ������ ��������� �������
    return 'tmpl_saved';
  }
  else
  {
    $self->getRow($ret, 3, $ret1->{'values'}, $ret1->{'errors'});
    return 'tmpl_row_edit';
  }
}

sub doIns
{
  my $self = shift;
  my $ret = shift;
  $self->getRow($ret, 2);
  return 'tmpl_row_edit';
}

sub doDel
{
  my $self = shift;
  my $ret = shift;
  if ( $self->delRow($ret) )
  {
    # �������� ��������
    return 'tmpl_deleted';
  }
  else
  {
    # ��� �������� �������� ������
    return 'tmpl_error';
  }
}

# -----------------------------------------------------------------------------

1;

__END__


=head1 AUTHOR

    Alexey Kovrizhkin <jean@jast.ru>

=head1 VERSION

    $Id: tbledit.pl,v 1.2 2006/06/26 19:29:12 jean Exp $

=cut

###############################################################################
