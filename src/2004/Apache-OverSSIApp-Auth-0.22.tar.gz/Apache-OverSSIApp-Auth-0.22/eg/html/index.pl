# $Id: index.pl,v 1.3 2004/08/08 18:46:24 jean Exp $
# CGI launcher example

# if placed in user directory
#use lib '/path_to_module/lib';

use CGI::Carp qw(fatalsToBrowser);

use Apache;
use Apache::OverSSI;	# if you want PerlSSI
use Apache::OverSSIApp::Auth;
return Apache::OverSSIApp::Auth::handler(Apache->request());

1;
