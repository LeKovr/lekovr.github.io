// j__menu

 #include "j__const.h"
 #include "j__shell.h"

 #define maxpos 11
 extern char far *vid_mem;

  /*            �뢥�� ��祧��饥 ���� � ������ �롮�            */
  /* ������ :      -3  ->  ����� ��५�� �����                   */
  /*                -2  ->  ����� ��५�� ��ࠢ�                  */
  /*                -1  ->  ����� ������ ESC (�᫨ ��⠭. 䫠�)  */
  /*               >=0  ->  ����� ��࠭��� ����樨                */

 // ***************************************************************

 menuptr *menudyninit
          (char **menu,        //  ᯨ᮪ ��ப ����
	   int count,          //  �᫮ ����権
	   int x, int y,       //  ���� ���孨� 㣮�
	   int escf,           //  䫠� Esc
	   int shf)            //  䫠� ⥭�
   { register int i,len;
     int endx,endy;
     int vv, cnt;
     menuptr *buff;
     if (shf) shf=1; else shf=0;
     len=0; /* ���᫨�� ����. ����� ����樨 */
     for (i=0;i<count;i++) if(strlen(*(menu+i))>len)
	 len=strlen(*(menu+i));
     cnt=count;
     if (count>maxpos) count=maxpos;
     if (x>24 || x<0) x=1;
     if (y>79 || y<0) y=1;
     if (x==0) x=10-count/2;
     if (y==0) y=38-len/2;
     endy=len+3+y;
     endx=count+1+x;
     if (endx+1>24) {  x=2; endx=count+1+x;
                    }
     if (endy+(shf*2)>79) { if (len>60 ) len=60;
                            endy=77; y=endy-len-3;
                          }
     vv=2*(count+2+shf)*(len+4+shf*2);
     buff=salloc(1,sizeof(menuptr));
     buff->p=salloc(vv,sizeof(char));
     buff->count=cnt;
     buff->escf=escf;
     buff->shf=shf;
     buff->len=len;
     buff->x=x; buff->y=y;
     buff->endx=endx; buff->endy=endy;
   return buff;
  }

 int menudynact (char **menu,      /*  ⥪�� ����          */
                 menuptr *buff)
   { register int i;
     int choice, cnt;
     extern int getrespdyn (int x,int y,int count,int len,
			  char **menu,int fl);
     extern int getrespdynbig (int x,int y,int count,int len,
			  char **menu,int fl);
     save_video(buff->x,buff->y,buff->endx,buff->endy,buff->p,buff->shf);
     draw_border(buff->x,buff->y,buff->endx,buff->endy,nmnatr);
     if (buff->count>maxpos) cnt=maxpos; else cnt=buff->count;
     for (i=0;i<cnt;i++)
         write_string(buff->x+1+i,buff->y+1,*(menu+i),nmnatr,buff->len);
     if (buff->count>maxpos)
        choice=getrespdynbig(buff->x+1,buff->y+1,buff->count,buff->len,
                             menu,buff->escf);
        else choice=getrespdyn(buff->x+1,buff->y+1,buff->count,buff->len,
                               menu,buff->escf);
     restore_video(buff->x,buff->y,buff->endx,buff->endy,buff->p,buff->shf);
     return choice;
   }

 static int getrespdyn (int x,int y,int count,int len,
	       char **menu, int fl)
     /* ���� �롮� ���짮��⥫� */
   { int arrow_choice=0,key_choice,ff=0,key;
      /* �뤥���� ���� �롮� */
     write_string(x,y,*menu,rmnatr,len);
     bottom (" Enter - �롮�    Esc - ��室     Navi - ����� ");
     for (;;) {
	      key=getsym();
     /* ������ �롮� � ��ଠ��� ०�� */
     write_string(x+arrow_choice,y,*(menu+arrow_choice),nmnatr,len);
	    switch (key) {
	      case KEnter  : return arrow_choice;
	      case KSpace  : arrow_choice++; break;
	      case KEsc    : if (fl) return -1;
                               else arrow_choice=ff=0; break;
	      case KCUp    : arrow_choice--; ff=0; break;
              case KPgUp   :
	      case KHome   : arrow_choice=0;ff=0; break;
              case KPgDn   :
	      case KEnd    : arrow_choice=count-1;ff=0; break;
	      case KCDown  : arrow_choice++; ff=0; break;
	      case KCLeft  : return -3;
	      case KCRight : return -2;
              default      : continue;
	    }
	 if (arrow_choice==count) arrow_choice=0;
	 if (arrow_choice<0) arrow_choice=count-1;
     /*  ���ᢥ��� ��࠭��� ������ */
	 write_string(x+arrow_choice,y,*(menu+arrow_choice),rmnatr,len);
     }
   }
 static int getrespdynbig (int x,int y,int count,int len,
	       char **menu, int fl)
     /* ���� �롮� ���짮��⥫� */
   { int choice,key;
     int lin1,lin9,move,i;
     int cnt=(maxpos-1)/2;
      /* �뤥���� ���� �롮� */
     write_string(x,y,*menu,rmnatr,len);
     lin1=choice=move=0;
     lin9=count-maxpos;
     bottom (" Enter - �롮�    Esc - ��室     Navi - ����� ");
     for (;;) {
     /*  ���ᢥ��� ��࠭��� ������ */
	 write_string(x+move,y,*(menu+choice),rmnatr,len);
	      key=getsym();
     /* ������ �롮� � ��ଠ��� ०�� */
     write_string(x+move,y,*(menu+choice),nmnatr,len);
	    switch (key) {
	      case KEnter  : return choice;
	      case KSpace  : move=1; break;
	      case KEsc    : if (fl) return -1;
                               else move=-choice; break;
	      case KCUp    : move=-1; break;
	      case KHome   : move=-choice; break;
	      case KEnd    : move=count-choice-1; break;
	      case KCDown  : move=1; break;
              case KPgUp   :
	      case KCLeft  : move=-maxpos; break;
              case KPgDn   :
	      case KCRight : move=maxpos;
              default      : continue;
	    }
         if (choice+move<0) move=-choice;
         if (choice+move>=count) move=count-choice-1;
         choice+=move;
         if (move && lin1==lin9 && count-choice<=cnt)
          { lin1=lin9; move=choice-lin1; continue; }
         if (!move && !lin1 && choice<cnt)
          { move=choice-lin1; continue; }
         if (choice<cnt+1) lin1=0;
            else if (count-choice<=cnt+1) lin1=lin9;
                    else lin1=choice-cnt;
         move=choice-lin1;
         for (i=0;i<maxpos;i++)
         write_string(x+i,y,*(menu+i+lin1),nmnatr,len);
       }
   }

 menuptr *menustatinit ( char *menu[],      /*  ⥪�� ����          */
	   char *key,       /*  ����稥 ������     */
	   int count,        /*  �᫮ ����権       */
	   int x,            /*  ���� ���孨� 㣮�  */
	   int y,
	   int escfl,     /*  䫠� Esc            */
	   int shfl )
   { register int i,lens;
     int endx,endy;
     char *hks;
     int vv;
     menuptr *buff;
     buff=salloc(1,sizeof(menuptr));
     buff->hkeys=hks=salloc(count+1,1); *(hks+count)='\0';
     buff->keys=key;
     buff->count=count;
     for (i=0;i<count;i++) *(hks+i)=keytohot(*(key+i));
     if (shfl) shfl=1; else shfl=0;
     buff->escf=escfl;
     buff->shf=shfl;
     lens=0; /* ���᫨�� ����. ����� ����樨 */
     for (i=0;i<count;i++) if(strlen(menu[i])>lens) lens=strlen(menu[i]);
     buff->len=lens;
     if (x>24 || x<0) x=1;
     if (y>79 || y<0) y=1;
     if (x==0) x=10-count/2;
     if (y==0) y=38-lens/2;
     endy=lens+3+y;
     endx=count+1+x;
     if (endx+1>24) { if (count>20) count=20;
                      x=2; endx=count+1+x;
                    }
     if (endy+(shfl*2)>79) { if (lens>60 ) lens=60;
                            endy=77; y=endy-lens-3;
                          }
     buff->x=x; buff->y=y;
     buff->endx=endx; buff->endy=endy;
     /* ࠧ��饭�� ����� ��� ��������� */
     vv=2*(count+2+shfl)*(lens+4+shfl*2);
     buff->p=salloc(vv,sizeof(char));
   return buff;
  }

  int menustatact (char *menu[],      /*  ⥪�� ����          */
	   char *stat[],     //  �������ਨ
	   char *flags,     /*  䫠�� ����᪠      */
           menuptr *buff)
   { register int i;
     int choice,atr,ff,key,lbye=0;
     save_video(buff->x,buff->y,buff->endx,buff->endy,buff->p,buff->shf);
     draw_border(buff->x,buff->y,buff->endx,buff->endy,nmnatr);
     for (i=0;i<buff->count;i++)
         write_string(buff->x+1+i,buff->y+1,menu[i],nmnatr,buff->len);
     for (i=0;i<buff->count;i++)
	 { if (*(flags+i)=='1')
	   write_char(buff->x+1+i,buff->y+1+is_in(menu[i],*(buff->keys+i)),
                      *(buff->keys+i),hmnatr);
	 }
  //  main circle
       choice=0;
   /* �뤥���� ���� �롮� */
     write_string(buff->x+1,buff->y+1,menu[0],rmnatr,buff->len);
   bottom (" Enter,Hot-key - �롮�     Esc - �⬥�a      Navi - ����� ");
    do  {
	  status (stat[choice]);
	  ff=*(flags+choice)-'0';
	  do { key=getsym();
	     } while (key==KEnter && !ff);
   /* ������ �롮� � ��ଠ��� ०�� */
	 write_string(buff->x+choice+1,buff->y+1,menu[choice],
                      nmnatr,buff->len);
	  if (*(flags+choice)=='1') { i=choice;
   write_char(buff->x+1+i,buff->y+1+is_in(menu[i],*(buff->keys+i)),
              *(buff->keys+i),hmnatr);
					   }
	    switch (key) {
	      case KEnter  : lbye=choice+10; break;
	      case KSpace  : choice++; break;
	      case KEsc    : if (buff->escf) lbye=-1;
              case KPgUp   :
              case KHome   : choice=0; break;
	      case KCUp    : choice--; break;
	      case KCLeft  : lbye=-3; break;
	      case KCRight : lbye= -2; break;
              case KPgDn   :
	      case KEnd    : choice=buff->count-1; break;
	      case KCDown  : choice++; break;
	      default      : if ((i=is_in(buff->hkeys,keytohot(key))) &&
				*(flags+i-1)=='1') lbye=9+i; break;
	    }
    if (lbye!=0) break;
	 if (choice==buff->count) choice=0;
	 if (choice<0) choice=buff->count-1;
     /*  ���ᢥ��� ��࠭��� ������ */
	 if (*(flags+choice)=='1')
            { atr=rmnatr;
   bottom (" Enter,Hot-key - �롮�     Esc - �⬥�a      Navi - ����� ");
            }
            else { atr=0;
     bottom (" Hot-key - �롮�     Esc - �⬥�a      Navi - ����� ");
                 }
	 write_string(buff->x+choice+1,buff->y+1,menu[choice],atr,buff->len);
     } while (1);
     if (lbye>=10) lbye-=10;
     restore_video(buff->x,buff->y,buff->endx,buff->endy,buff->p,buff->shf);
     return lbye;
   }


 menuptr *helpwininit (char *menu[],  //  ���ᨢ ��ப ⥪��
                char *head,    //  ���������
	         int count)    //  �᫮ ����権
   { register int i,len;
     int x,y,endx,endy,choice, vv;
     menuptr *buff;
     len=0; /* ���᫨�� ����. ����� ����樨 */
     for (i=0;i<count;i++) if(strlen(menu[i])>len) len=strlen(menu[i]);
      x=10-count/2;
      y=38-len/2;
     endy=len+3+y;
     endx=count+1+x;
     if (endx+1>24) { if (count>20) count=20;
                      x=2; endx=count+1+x;
                    }
     if (endy+(2)>79) { if (len>60 ) len=60;
                            endy=77; y=endy-len-3;
                          }
     buff=salloc(1,sizeof(menuptr));
     buff->count=count;
     buff->len=len;
     buff->x=x; buff->y=y;
     buff->keys=head;
     buff->endx=endx; buff->endy=endy;
     /* ࠧ��饭�� ����� ��� ��������� */
     vv=2*(count+2+1)*(len+4+1*2);
     buff->p=salloc(vv,sizeof(char));
   return buff;
  }
 void helpwinact (char *menu[],
                  menuptr *buff,
	         int nv,       //  ��ਡ��� :  ⥪��
	         int bnv)      //              �����
     {
     save_video(buff->x,buff->y,buff->endx,buff->endy,buff->p,1);
     drawbord(buff->x,buff->y,buff->endx,buff->endy,2,buff->keys,0,bnv);
    { register int i;
      for (i=0;i<buff->count;i++)
      write_string(buff->x+1+i,buff->y+1,menu[i],nv,buff->len);
    }
    bottom ("         ������ ���� ������� ");
    getsym();
     restore_video(buff->x,buff->y,buff->endx,buff->endy,buff->p,1);
   }
 // *****************************
 // **   ��ਧ��⠫쭮� ����   **
 // *****************************

 static char *menuln;    //
 static char *hkeysln;
 static char far *startln;
 static int countln;
 static int lenln;
 static int xln, yln;

 extern char far *vid_mem;

 static struct positions
	{ int y0;
	  int yh;
	  int len;
	} *positln;


 void menulininit (int x, int y, char *menu, char *keys, int cnt)
    { int i, cp=0, cl=0;
      startln=vid_mem+x*160+y*2;
      xln=x; yln=y;
      menuln=menu; countln=cnt; lenln=strlen(menu);
      hkeysln=salloc(cnt,sizeof(char)); *(hkeysln+cnt)='\0';
      positln=salloc(cnt,sizeof(struct positions));
      for (i=0;i<cnt;i++) *(hkeysln+i)=keytohot(*(keys+i));
      for (i=0;i<lenln;i++)
	  { if (*(menu+i)==' ' && *(menu+i+1)!=' ' && !cl)
	       { (positln+cp)->y0=i; cl=1; continue; }
	    if (*(menu+i)==*(keys+cp))
	       { (positln+cp)->yh=i; cl++; continue; }
	    if (*(menu+i)==' ' && *(menu+i+1)==' ' && cl)
	       { (positln+cp)->len=cl+1; cl=0; cp++; continue; }
	    if (cl) cl++;
	  }
      goto_xy(50,50);
    }

 int menulinact (char *flags, int pos1, int mode)
   { int i,j,atr,lt,curp,ch,ready;
     extern int positinit (int i0, int mod, char *flg);
     curp=positinit(pos1,mode,flags);
     do { write_string(xln,yln,menuln,nmnatr,lenln); ready=*(flags+curp)-'0';
	  for (i=0;i<countln;i++)
	      { if (i==curp)
		   { if (*(flags+i)=='1') atr=rmnatr; else atr=0;
		     lt=(positln+i)->y0*2+3;
		     for (j=0;j<(positln+i)->len;j++, lt+=2)
			 *(startln+lt)=atr;
		   }
		else { if (*(flags+i)=='1')
		       *(startln+(positln+i)->yh*2+3)=hmnatr;
		     }
	      }
	  if (mode!=0) return curp;
	  if (*(flags+curp)=='1')
	     {
	  bottom (" Enter,Down,Hot-key - �롮�    Navi,Space - ����� ");
	       switch (curp) {
   case 0 : status ("������ ���ଠ樨 �� ���"); break;
   case 1 : status ("���� ��室��� ������ ����� "); break;
   case 2 : status ("��ࠡ�⪠ ������"); break;
   case 3 : status ("���ᠭ�� ���᫥���, ����䥩� � �.�."); break;
			     }
	     }
	     else {
	  bottom (" Hot-key - �롮�    Navi,Space - ����� ");
	       switch (curp) {
   case 2 : status ("��। ���᫥��ﬨ ����室��� ����� �����"); break;
   case 0 : status ("���� �� ��祣� �����뢠��"); break;
		     }
		  }
	  do { ch=getsym();
	     } while ((ch==KEnter || ch==KCDown) && !ready);
	  switch (ch) {
		 case KEnter  :
		 case KCDown  : return curp;
                 case KEsc    : return -1;
		 case KCLeft  : curp--; break;
		 case KCRight :
		 case KSpace  : curp++; break;
		 default      : if ((i=is_in(hkeysln,keytohot(ch))) &&
				*(flags+i-1)=='1') { curp=i-1; mode=1; }
		     }
	  if (curp<0) curp=countln-1;
	  if (curp==countln) curp=0;
	} while (1);
   }
 static int positinit (int i0, int md, char *flg)
      { do { i0+=md;
	     if (i0<0) i0=countln-1;
	     if (i0>=countln) i0=0;
	   } while (*(flg+i0)!='1');
	return i0;
      }

  void menulineclose ()
  {
    sfree (hkeysln);
    sfree (positln);
  }

 // ***************

  void message (int mode, char *st)
   { int a,x0,x1,x2,y1,y2;
     char *p;
     extern point dwin,vwin;
     bell();
     switch (mode) {
	      case 1 : x0=vwin.x+vwrow/2; break;
              case 2 : x0=dwin.x+dwrow/2; break;
              default : x0=12;
              }
     if (x0<5) x0=5; else if (x0>20) x0=20;
     a=strlen(st)+6; if (!a || a>maxsym) a=40;
     y1=40-a/2; y2=y1+a-1; x1=x0-3; x2=x0+3; x0--;
     p=calloc (2*8*(a+2),sizeof(char));
     save_video (x1,y1,x2,y2,p,1);
     clw (x1,y1,a,7,matr);
     draw_border (x1,y1,x2,y2,matr);
     write_string (x0,y1+2,st,matr,a-6);
     write_string (x0+2,37," Ok ",matr1,4);
     bottom ("       ⮫쪮 Enter... ");
     while (getsym()!=KEnter);
     bottom (" ");
     restore_video(x1,y1,x2,y2,p,1);
     free(p);
  }

 char *ask (char *quest,       //  ⥪�� �����
	    char *def,         //  �⢥� �� 㬮�砭��
	    int len1,          //  �ਭ� ����
	    int len,           //  ����� ��ப� �⢥�
	    int fonatr,        //  ��ਡ��� : 䮭
	    int ansatr)        //             �⢥�
  {  int x0,a,y1,y2,x1,x2,c,y3,vlen,i,cf;
     char *p, *res;
     x0=12;
     a=len1+6; if (!a || a>maxsym) a=40;
     y1=40-a/2; y2=y1+a-1; x1=x0-3; x2=x0+3; x0--;
     p=salloc (2*8*(a+2),sizeof(char));
     res=salloc(len+1,sizeof(char));
     vlen=strlen(def);
     for (c=0;c<vlen;c++) *(res+c)=*(def+c);
     for (;c<len;c++) *(res+c)=' ';
     *(res+len)='\0'; len--;
     save_video (x1,y1,x2,y2,p,1);
     clw (x1,y1,a,7,fonatr);
     draw_border (x1,y1,x2,y2,fonatr);
     c=strlen(quest);
     y3=39-c/2;
     write_string (x0,y3,quest,fonatr,c);
     cf=0;
     do { write_string (x0+2,39-len/2,res,ansatr,len);
	  goto_xy(x0+2,39-len/2+vlen+1);
bottom (" Enter - �롮�  Esc - �⬥��   Space - ������   Navi - ����� ");
	  i=getsym();
	  switch(i) {
	     case KBkSp   : cf=1; if (vlen>0)
                                   { for (a=vlen-1;a<len;a++)
				     *(res+a)=*(res+a+1); vlen--;
				   }
		            break;
	     case KEnter  : cf=2; break;
	     case KDel    : if (vlen==len) break;
		            *(res+vlen)=' '; cf=1;
		            for (a=vlen;a<len;a++) *(res+a)=*(res+a+1);
		            break;
	     case KEsc    : sfree(res); *res='\n'; cf=2; break;
	     case KCLeft  : if (vlen>=0) vlen--; cf=1; break;
	     case KCRight : if (vlen<len) vlen++; cf=1; break;
	     default : if (i<KSpace || i>255) break;
		       if (!cf)
			{ for(a=0;a<vlen;a++) *(res+a)=' ';
			  vlen=0; cf=1;
			}
		       if (vlen==len) break;
		       *(res+vlen)=i; vlen++; break;
	     }
	} while (cf!=2);
     restore_video(x1,y1,x2,y2,p,1);
     sfree(p);
     return res;
 }

 int askbin (int mode, char *quest, int pos1, int escf)
   { int a,x0,x1,x2,y1,y2,anslen=12,bye=0,
         pp1[2] = { 0,7 },lens[2] = { 5,5 },
         yl,st,choice,ch;
     char *p, *answ;
     extern point dwin,vwin;
     answ=" ��     ��� ";
     switch (mode) {
	      case 1 : x0=vwin.x+vwrow/2; break;
              case 2 : x0=dwin.x+dwrow/2; break;
              default : x0=12;
              }
     if (x0<5) x0=5; else if (x0>20) x0=20;
     a=strlen(quest)+6; if (!a || a>maxsym) a=40;
     if (a<anslen) a=anslen;
     y1=40-a/2; y2=y1+a-1; x1=x0-3; x2=x0+3; x0--;
     yl=40-anslen/2;
     p=calloc (2*8*(a+2),sizeof(char));
     save_video (x1,y1,x2,y2,p,1);
     clw (x1,y1,a,7,nmnatr);
     drawbord (x1,y1,x2,y2,1," ",0,nmnatr);
     write_string (x0,y1+2,quest,nmnatr,a-6);
     if (pos1) pos1=1;
     choice=pos1;
     if (escf)
         bottom (" Enter - �롮�      Esc - �⬥��     Navi - ����� ");
        else   bottom ("        Enter - �롮�          Navi - ����� ");
     do {
     write_string (x0+2,yl,answ,nmnatr,12);
    write_string(x0+2,yl+pp1[choice],answ+pp1[choice],rmnatr,lens[choice]);
           ch=getsym();
	  switch (ch) {
		 case KEnter  : bye=choice+10; break;
		 case KCLeft  : choice--; break;
		 case KCRight :
		 case KSpace  : choice++; break;
                 case KEsc    : if (escf) bye=9; break;
                      }
         if (choice>1) choice=0;
         if (choice<0) choice=1;
         } while (!bye);
     bottom (" ");
     restore_video(x1,y1,x2,y2,p,1);
     free(p);
     return bye-10;
   }

