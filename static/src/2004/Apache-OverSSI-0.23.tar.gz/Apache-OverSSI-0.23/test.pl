# Before `make install' is performed this script should be runnable with
# `make test'. After `make install' it should work as `perl test.pl'

#########################

# change 'tests => 1' to 'tests => last_test_to_print';
use FindBin qw($Bin);
use lib "$Bin/lib";

use Test;
BEGIN { plan tests => 11 };

use Apache::OverSSI::Command;		ok(1);
use Apache::OverSSI::Config;		ok(1);
use Apache::OverSSI::DBI;		ok(1);
use Apache::OverSSI::DBM;		ok(1);
use Apache::OverSSI::Exception;		ok(1);
use Apache::OverSSI::Mailer;		ok(1);
use Apache::OverSSI::MethodMaker;	ok(1);
use Apache::OverSSI::Request;		ok(1);
use Apache::OverSSI::Server;		ok(1);
use Apache::OverSSI::Utils;		ok(1);
use Apache::OverSSI;			ok(1);

#########################

