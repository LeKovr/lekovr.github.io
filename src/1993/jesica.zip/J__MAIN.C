// j__main

 extern char *main_flags;

 void main (args,argv)
      int args;
      char *argv[];
  { int i=0,j=1;
    setup(args-1);
    do {
	 j=menulinact (main_flags,j,i);
	 switch (j) {
	    case 0 : i=save(); break;
	    case 1 : i=input(); break;
	    case 2 : i=calc(); break;
	    case 3 : i=helper(); break;
            case -1 : status ("����� Esc �� �������� ���� ");
                      bell(); bell();
                      { int k=askbin (0,"�������� ࠡ��� ?",0,1);
                        if (k==0) park(0);
                      }
		    }
        } while (1);
 }

