// j__utscr

 #include <dos.h>
 #include "j__const.h"
 #include "j__shell.h"

 extern char far *vid_mem;
 extern point dwin,vwin;

 void write_char (int x,int y,char ch,int attrib);
 void write_string (int x,int y,
		    char *p,
		    int attrib,int len);
 void outstr (int x,int y,int j,list *mem,int col);
 void outwin (int x,int y,int row,int col,list *mem);
 void scroll (int x1,int y1,     /* � �।���� 㪠������� ���� */
	      int x2,int y2,
	      int lines,         /* �� lines ��ப             */
	      int direct,        /* � ���ࠢ����� direct       */
	      int atr);
					/* ᤢ����� ⥪��             */
 void clw (int x,int y,int wcol,int wrow,int atr);
 void draw_border (int startx,int starty,
		   int endx,int endy,
		   int atr);
 void drawbord (int stx,int sty,int endx,int endy,
                   int typch,char *head, int hon,
		   int atr);
 int curup (int i,int x1,int y1,int wc,int wr,
	    list *mem,
	    int *l1,int *vr,int *dr,
	    int atr);
 int curdn (int i,int x1,int y1,int wc,int wr,int maxr,
	    list *mem,
	    int *l1,int *vr,int *dr,
	    int atr);
 void videomode ();
 void status (char *str);
 void bottom (char *str);
 void restore_video (int startx,int starty,
		     int endx,int endy,
		     char *buf_ptr,
		     int f);
 void save_video (int startx,int starty,
		  int endx,int endy,
		  char *buf_ptr,
		  int f);
 #define index 500
 int getsym ();
 void goto_xy(int x, int y);

 void outstr (int x,int y,int j,list *mem,int col)
   {  int i;
      char far *v;
      v=vid_mem+(x+j)*160+y*2;
      for (i=0;i<col;i++)
	  { *v++=(*mem).dat[i].ch;
	    *v++=(*mem).dat[i].at;
	  }
   }
 void outwin (int x,int y,int row,int col,list *mem)
   { int i;
     for (i=0;i<row;i++) { outstr(x,y,i,mem,col);mem=(*mem).next;}
   }

 void scroll (int x1,int y1,     /* � �।���� 㪠������� ���� */
	      int x2,int y2,
	      int lines,         /* �� lines ��ப             */
	      int direct,        /* � ���ࠢ����� direct       */
	      int atr)
					/* ᤢ����� ⥪��             */
 { union REGS r;
  if (direct==0) r.h.ah=6; /* �஫���� ����� */
	     else r.h.ah=7; /* �஫��� ����   */
   r.h.al=lines;  /* */
   r.h.ch=x1; /* */
   r.h.cl=y1; /* */
   r.h.dh=x2;   /* */
   r.h.dl=y2;   /* */
   r.h.bh=atr;      /*   ०�� �⮡ࠦ���� */
   int86 (0x10,&r,&r);
  }

  void goto_xy (int x,int y)
 { union REGS r;
   r.h.ah=2;
   r.h.dh=x;
   r.h.dl=y;
   r.h.bh=0;
   int86 (0x10,&r,&r);
  }

  getsym ()
  { union REGS r;
    int res;
    r.h.ah=7;
    int86(0x21,&r,&r);
    switch (r.h.al) {
	   case 13 : res=index; break;
	   case 27 : res=index+1; break;
	   case  0 : int86(0x21,&r,&r); res=index+r.h.al; break;
	   default : res=r.h.al;
    }
    goto_xy(50,50);
    if (res==545) park(0);
    return res;
  }

 int curup (int i,int x1,int y1,int wc,int wr,
	    list *mem,
	    int *l1,int *vr,int *dr,
	    int atr)
  {  int x2,y2;
     int res,a;
     list *lmem;
     if (!i) return;
     if (*dr<i) {i=*dr; res=1;} else res=0;
     if (*vr>=i) { (*vr)-=i; (*dr)-=i; return res; }
     a=i-*vr; (*dr)-=i; (*l1)-=a;*vr=0;
     x2=x1+wr-1; y2=y1+wc-1; lmem=mem;
     for (i=0;i<(*l1);i++) lmem=(*lmem).next;
     if (2*a<wr) { scroll (x1,y1,x2,y2,a,1,atr);
		   outwin (x1,y1,a,wc,lmem);
		 }
	      else outwin (x1,y1,wr,wc,lmem);
     return res;
  }

 int curdn (int i,int x1,int y1,int wc,int wr,int maxr,
	    list *mem,
	    int *l1,int *vr,int *dr,
	    int atr)
  {  int x2,y2;
     int res,a,b;
     list *lmem;
     // if (!i) return;
     if ((*dr)+i+1>maxr) {i=maxr-(*dr)-1; res=1;} else res=0;
     if (!i) return;
     if ((*vr)+i<wr) {(*vr)+=i; (*dr)+=i; return res; }
     a=i+*vr-wr+1; lmem=mem;
     (*dr)+=i; (*vr)=wr-1; (*l1)+=a;
     if (2*a<wr) { x2=x1+wr-1; y2=y1+wc-1;
		   scroll (x1,y1,x2,y2,a,0,atr);
		   x2=wr-a+x1; y2=y1; b=a;
		 }
	    else { x2=x1; y2=y1; b=wr;}
     for (i=0;i<((*dr)-b+1);i++) lmem=(*lmem).next;
     outwin (x2,y2,b,wc,lmem);
     return res;
  }

  void clw (int x,int y,int wcol,int wrow,int atr)
  { point win1;
    scroll(x,y,x+wrow-1,y+wcol-1,0,0,atr);
  }

  void status (char *str)
     { drawbord(21,0,23,maxsym+1,2,"  �������� :   ",10,satr|INTENSE);
       write_string(22,3,str,satr,maxsym-4);
       drawbord(21,0,23,maxsym+1,1,"  �������਩  ",10,satr);
     }
   
  void bottom ( char *str)
   { write_string(24,3,str,headatr,maxsym-4);
   }

  void draw_border (int startx,int starty,
		   int endx,int endy,
		   int atr)
    { register int i;
      char far *v, far *t;
      v=vid_mem; t=v;
      for (i=startx+1;i<endx;i++) {
	  v+=(i*160)+starty*2;
	  *v++=179; *v=atr; v=t;
	  v+=(i*160)+endy*2;
	  *v++=179; *v=atr; v=t;
      }
      for (i=starty+1;i<endy;i++) {
	  v+=(startx*160)+i*2;
	  *v++='�'; *v=atr; v=t;
	  v+=(endx*160)+i*2;
	  *v++='�'; *v=atr; v=t;
      }
      write_char (startx,starty,218,atr);
      write_char (startx,endy,191,atr);
      write_char (endx,starty,192,atr);
      write_char (endx,endy,217,atr);
    }

 void drawbord (int stx,int sty,int endx,int endy,
                   int typch,char *head, int hon,
		   int atr)
                       { register int i;
      char *dbbrd="      ��ڿ�ٺ�ɻȼ", *dd, ch;
      char far *v, far *t;
      int len, hoff;
      len=strlen(head);
      if (len>1) { if (!hon) hon=(endy-sty-len)/2+sty;
                      else hon+=sty;
                   hoff=hon+len;
                 }
                     else { hoff=0; }
      if (typch>1) typch=2;
      dd=dbbrd+6*typch;
      ch=*dd++;
      v=vid_mem; t=v;
      for (i=stx+1;i<endx;i++) {  v+=(i*160)+sty*2;
 	                             *v++=ch; *v=atr; v=t;
	                             v+=(i*160)+endy*2;
	                             *v++=ch; *v=atr; v=t;
                                  }
      ch=*dd;
      for (i=sty+1;i<endy;i++) { if (i>=hon && i<hoff) ch=*head++;
	  v+=(stx*160)+i*2;
	  *v++=ch; *v=atr; v=t; ch=*dd;
	  v+=(endx*160)+i*2;
	  *v++=ch; *v=atr; v=t;
      }
      dd++;
      write_char (stx,sty,*dd++,atr);
      write_char (stx,endy,*dd++,atr);
      write_char (endx,sty,*dd++,atr);
      write_char (endx,endy,*dd++,atr);
    }
   void write_string (int x,int y,
		      char *p,
		      int attrib,int len)
      { register int i;
        int ln, fl=0;
	char far *v;
	v=vid_mem;
	v+=x*160+y*2;   /* ���᫨�� ���� */
	*v++=' '; *v++=attrib; /* ������� ���� �஡�� */
        if (strlen(p)>len) ln=len; else { fl=1; ln=strlen(p); }
	for (i=y;ln;i++,ln--,len--) {
	    *v++=*p++; *v++=attrib;  /* �뢥�� ᨬ��� � ��ਡ��� */
	}
        if (fl) {
	for (i=len;len+1;len--) {  /* ������� �஡��� �� ���� ��ப� */
	 *v++=' '; *v++=attrib;
	}
                 }
      }
   void write_char (int x,int y,char ch,int attrib)
      { register int i;
	char far *v;
	v=vid_mem; v+=(x*160)+y*2;
	*v++=ch; *v=attrib;
      }
   void save_video (int startx,int starty,
		    int endx,int endy,
		    char *buf_ptr,
		    int f)
      { register int i,j;
        int vv=0;
	char far *v, far *t;
	v=vid_mem; if (f) f=1; else f=0;
	for (i=starty;i<endy+1+f+f;i++)
	    for (j=startx;j<endx+1+f;j++) {
		t = v+(j*160)+i*2;
		*buf_ptr++=*t++; *buf_ptr++=*t;   vv++; vv++;
		if (j==endx+1) { if (f && i>(starty+1)) *t=shatr; }
		   else if (i>endy) { if (f && j>startx) *t=shatr; }
			   else *(t-1)=' ';
	    }
      }

   void restore_video (int startx,int starty,
		    int endx,int endy,
		    char *buf_ptr,
		    int f)
      { register int i,j,k;
        int vv=0;
	char far *v, far *t;
	v=vid_mem; t=v; if (f) f=1; else f=0;
	for (i=starty;i<endy+1+f+f;i++)
	    for (j=startx;j<endx+1+f;j++) {
		v=t; v+=(j*160)+i*2;
		*v++=*buf_ptr++; *v=*buf_ptr++;  vv++; vv++;
//		for (k=1;k<100;k++); /* ����প� ��� ᮫������ */
	    }
      }

