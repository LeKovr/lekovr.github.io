package Apache::OverSSIApp::DBITableConfig;

# $Id: DBITableConfig.pm,v 1.3 2004/10/13 20:42:25 aleko Exp $

=head1 NAME

Apache::OverSSIApp::DBITable::Config - Internal package

=head1 DESCRIPTION

Apache::OverSSIApp::DBITable is a simple utility for form data saving
and restoring with authorization via email
based on Apache::OverSSI library

=over 4

=cut
    
use strict;
use warnings;

use Params::Validate qw(:all);

use base qw(Apache::OverSSI::Config);

our $VERSION = sprintf("%d.%02d", '$Revision: 1.3 $' =~ /(\d+)\.(\d+)/);

BEGIN {
    __PACKAGE__->valid_params (
	dbi_dsn => {
    	    type => SCALAR,
	    descr => 'DBI connect DSN' 
	},
	dbi_user => {
    	    type => SCALAR,
	    descr => 'DBI connect user' 
	},
	dbi_auth => {
    	    type => SCALAR,
	    descr => 'DBI connect password' 
	},
	sql => {
    	    type => SCALAR,
	    descr => 'SQL for data fetch' 
	},
	session_key => {
    	    type => SCALAR | UNDEF, default => undef,
	    descr => 'get id from this session var (required if session used' 
	},

	pre_sql => {
    	    type => SCALAR, default => undef,
	    descr => 'fill data with sql results for form select'
	},
	add_sql => {
    	    type => SCALAR, default => undef,
	    descr => 'fill data with additional sql results for request results' 
	},
	add_arg => {
    	    type => SCALAR, default => undef,
	    descr => 'put this args into ADD_SQL' 
	},
	dates_count => {
    	    type => SCALAR, default => 0, regex => qr/^\d{0,2}$/,
	    descr => 'date fields count' 
	},
	dates_type => {
    	    type => SCALAR, default => 'dmy', regex => qr/^[dmy]{0,3}$/,
	    descr => 'date fields format' 
	},
	args => {
    	    type => SCALAR, default => '',
	    descr => 'additional variables list ' 
	},
	do_empty => {
    	    type => SCALAR, default => undef,
	    descr => 'call main sql if none args present' 
	},
    );
}

use Apache::OverSSI::MethodMaker (
    read_only => [ 
	keys %{__PACKAGE__->validation_spec}
    ],
);

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: DBITableConfig.pm,v 1.3 2004/10/13 20:42:25 aleko Exp $

=cut

#######################################################################
