#!/usr/bin/perl

use strict;
use warnings;

use DBI;

my %db = (
    name => 'tbledit',
    user => 'jean',
    auth => '',
    sql  => 'select current_user,  current_date'
);

my $dbh = DBI->connect("dbi:Pg:dbname=$db{name}", $db{user}, $db{auth})
    or die "Connect: ".$DBI::errstr;

my @data = $dbh->selectrow_array($db{sql}) or die "SQL: ".$dbh->errstr;

$dbh->disconnect;

print "Result:\n",join "\n", @data, '';

1;
