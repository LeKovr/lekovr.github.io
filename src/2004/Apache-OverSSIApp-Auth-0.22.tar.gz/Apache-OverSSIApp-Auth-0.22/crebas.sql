-- $Id: crebas.sql,v 1.3 2004/08/08 18:46:20 jean Exp $
-- Demo database

--create database overssi;

drop table users;
create table users
(
    nick          VARCHAR(32)            not null    ,
    email         VARCHAR(32)            not null    ,
    auth          VARCHAR(32)            not null    ,
    isadmin       BOOL		         not null default false,
    constraint pk_users primary key (nick)
);

create unique index users_email_uniq on users (email);

-- password: root (crypted)
copy users (nick, email, auth, isadmin) from STDIN;
root	root@localhost	WQ9IhVoU9nwPs	t
8612060	user@localhost	WQ9IhVoU9nwPs	f
\.
