package Apache::OverSSI::Command;

# $Id: Command.pm,v 1.3 2004/08/08 19:14:28 jean Exp $

=head1 NAME

Apache::OverSSI::Command - class for application commands

=head1 DESCRIPTION

Apache::OverSSI is a library for lightweight mod_perl
applications which use SSI for output templating.
based on Apache, mod_perl, mod_include and mod_env.

=over 4

=cut

use strict;
use warnings;

use Params::Validate qw(:all);

use Class::Container;
use base qw(Class::Container);

our $VERSION = sprintf("%d.%02d", '$Revision: 1.3 $' =~ /(\d+)\.(\d+)/);

BEGIN {
    # Fields that can be set in new method, with defaults
    __PACKAGE__->valid_params (
	func => { 
	    type => CODEREF,
	    descr => "Code to run" 
	},
	args  => {
    	    type => SCALAR, optional => 1,
	    descr => "argument set id" 
	 },
	acl => {
    	    type => SCALAR, optional => 1,
	    descr => "ACL variable name" 
	 },
	subr => {
	    type => BOOLEAN, default => 0, 
    	    descr => "When true, we only allow subrequest (inside SSI) calls" 
	},

    );

}

use Apache::OverSSI::MethodMaker (
    read_only => [ 
	keys %{__PACKAGE__->validation_spec}
    ],
);
#----------------------------------------------------------------------

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(@_);

    $self->_initialize;
    return $self;
}

#----------------------------------------------------------------------
sub _initialize {

}

#----------------------------------------------------------------------

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: Command.pm,v 1.3 2004/08/08 19:14:28 jean Exp $

=cut

#######################################################################
