package Apache::OverSSIApp::USS;

# $Id: USS.pm,v 1.10 2004/08/24 21:19:14 aleko Exp $

=head1 NAME

Apache::OverSSIApp::USS - User Settings System based on Apache::OverSSI

=head1 DESCRIPTION

Apache::OverSSIApp::USS is a simple utility for form data saving
and restoring with authorization via email
based on Apache::OverSSI library

=over 4

=cut
    
use strict;
use warnings;

use base qw(Apache::OverSSI::Request);

use Fcntl qw(:flock);
use Apache::Constants qw(:common);

use Params::Validate qw(:all);

use Apache::OverSSI 0.21;
use Apache::OverSSI::Server;
use Apache::OverSSI::Command;
use Apache::OverSSI::Mailer;
use Apache::OverSSI::Utils;
use Apache::OverSSI::DBM;
use Apache::OverSSI::Exception;

use Apache::OverSSIApp::USSConfig;

use Data::Dumper;

our $VERSION = '0.22';
our $REVISION = sprintf("%d.%02d", '$Revision: 1.10 $' =~ /(\d+)\.(\d+)/);

my $srv; # ������������ �� ������ ������ � ����������� ����������

my @sysfields = qw(_regtime _lastmod _lastlog _currlog);
	
#	    _regtime => $t, 	# ���������������
#	    _lastmod => $t,	# ������� ������
#	    _lastlog => $t,	# ������� �����
#	    _currlog => $t,	# ������� �����

BEGIN {

    $srv = Apache::OverSSI::Server->new(
    
	# Module name for logging & global variables
	module_name => 'USS',

	sid_param => 'id',

	# Default command name
	default_command	=> 'load',
	
    );

    # commands: [subrequest, 0(user)|1(part)|2(topic), perm tag, pointer]
    $srv->command('login',    Apache::OverSSI::Command->new( func=> \&do_login ) );
    $srv->command('load',     Apache::OverSSI::Command->new( func=> \&do_load ) );
    $srv->command('save',     Apache::OverSSI::Command->new( func=> \&do_save ) );
    $srv->command('logout',   Apache::OverSSI::Command->new( func=> \&do_logout ) );

    __PACKAGE__->valid_params (
	f_select => {
    	    type => ARRAYREF, default => [],
	    descr => "Per request storage for form select" 
	 },
    );

}

use Apache::OverSSI::MethodMaker (
    read_only => [ 
	keys %{__PACKAGE__->validation_spec}
    ],
    read_write => [ qw( 
	is_admin
    ) ],
);

#----------------------------------------------------------------------

=item handler

Main procedure. Initializes variables and calls
requested command

=cut

sub handler {
    my $r = shift;

    my $rec = __PACKAGE__->new(server => $srv, request => $r);
    my @config = $rec->load_conf(keys %{Apache::OverSSIApp::USSConfig->validation_spec})
	or return NOT_FOUND;
    return $rec->run( Apache::OverSSIApp::USSConfig->new(@config) );
    
}

#----------------------------------------------------------------------
# login
# ACL: Guest
# Check user email and send him unique id 
# id => email are stored in keys database

sub do_login {
    my $s = shift;
    my $args = $s->args;

    my $email = $args->{'F_EMAIL'} = escape_html($s->param('F_EMAIL'));
    Exception->throw(code=>'11') unless ($email);

    my ($dbh, %db);
    $dbh = $s->open_db('users', \%db, LOCK_SH);
    my $u = $db{$email};
    $s->close_db($dbh);

    unless ($u) {
	Exception->throw(code=>'12') unless $s->config->addusers; # only old users
	Exception->throw(code=>'13', info => $email) if (mail_test($s, $email) ne ''); # bad email
    }

    # store key
    $dbh = $s->open_db('keys', \%db, LOCK_EX);

    $db{$s->unique_id} = {
	email => $email,
	start => time(),
	vrfy  => undef,
	code  => 31		# say welcome
    };
    $s->close_db($dbh);

    # send mail
    mail_key($s, $email);

    return '20';
}


#----------------------------------------------------------------------
sub check_session {
    my $s = shift;
    my $code = shift;    

    my $args = $s->args;

    my $sid = $s->sid;
    Exception->throw(code=>'15') unless $sid;
    
    $args->{$s->server->sid_param} = $sid if ($s->server->sid_param);

    my ($dbh, %db, $is_new, $exit);

    $dbh = $s->open_db('keys', \%db, LOCK_EX);
    my $key = $db{$sid};

    unless ($key) {
	$s->close_db($dbh);
	Exception->throw(code=>'16');
    }
    $is_new = 1 unless ( $key->{'vrfy'} );    
    $exit = $key->{'code'};
    $key->{'code'} = $code;
    # save last usage time
    # ToDo: expire $time or
    # return '17';
    # ToDo: External code to drop expired keys records
    $key->{'vrfy'} = time();
    $db{$sid} = $key;
    $s->close_db($dbh);

    my $email = $key->{'email'};

    $dbh = $s->open_db('users', \%db, LOCK_EX);

    my $user = $db{$email};
    my $t = localtime(time());
    unless ($user) {
	$s->print_log(3, "REGISTER: $email");
	$user = {};
	foreach my $fld (@sysfields) {
	    $user->{$fld} = $t;
	}
    } elsif ($is_new) {
	$user->{'_lastlog'} = $user->{'_currlog'};
	$user->{'_currlog'} = $t;
	$s->print_log(3, 'SID ACTIVATED');
    }

    if ($s->config->admin eq $email) {
	# admin user
	$s->is_admin(1);
	$s->print_log(4, 'ADMIN MODE');

	# login/logout use real email
	# load / save use email from args
	$args->{'F_EMAIL'} = ($is_new)?$email:$s->param('F_EMAIL');
    } else {
	# ReadOnly for usual user
	$args->{'F_EMAIL'} = $email;
    }

    $db{$email} = $user;
    $s->close_db($dbh);

    $s->print_log(3, "AUTH: $email");
    
    return $exit;
}

#----------------------------------------------------------------------
# load
# Authorize user if arg 'id' is present in request
# Fill %$args with user data

sub do_load {
    my $s = shift;
    my $code = check_session($s,0) || '30';
    my $args = $s->args;

    # do the work
    my ($dbh, %db);
    $dbh = $s->open_db('users', \%db, LOCK_SH);

    my $user = $db{$args->{'F_EMAIL'}};
    my @fields = mk_fields($s);
    foreach my $fld (@fields) {
	$args->{$fld} = escape_html($user->{$fld});
    }
    foreach my $fld (@sysfields) {
	$args->{$fld} = $user->{$fld};
    }

    my $r = $s->request;

    if ($s->is_admin) {
	# Add userlist combo
	my $data=$s->f_select;
	foreach my $e (keys %db) {
	    next if (ref(\$e) ne 'SCALAR'); # just in case
	    $s->print_log(4, 'ADD: ', $e);
	    push @$data, $e;
	}
	$args->{'D_USERSELECT'}='SSI_SEL1';
	$r->pnotes ('SSI_SEL1', $data);
    }

    $s->close_db($dbh);
    
    return $code;
}

#----------------------------------------------------------------------
sub do_save {
    my $s = shift;
    check_session($s, 32);	
    my $args = $s->args;

    # do the work
    my ($dbh, %db);
    $dbh = $s->open_db('users', \%db, LOCK_EX);
    my $user = $db{$args->{'F_EMAIL'}};

    my @fields = mk_fields($s);
    foreach my $fld (@fields) {
	# ToDo: check field presense
	$user->{$fld} = $s->param($fld);
    }
    $user->{'_lastmod'} = localtime(time());
    
    if ($s->is_admin) {
	my $nmail=$s->param('F_NMAIL');	# get new mail
	$db{$nmail} = $user;		# save in new
	if ($args->{'F_EMAIL'} ne $nmail) {
	    # email changed. Remove old.
	    delete $db{$args->{'F_EMAIL'}};
	    
	    $args->{'F_EMAIL'} = $nmail;
	}
    } else {
	$db{$args->{'F_EMAIL'}} = $user;
    }
    $s->close_db($dbh);

    my @v;
    push (@v, 'F_EMAIL='.$args->{'F_EMAIL'}) if ($s->is_admin);

    return $s->redirect($s->uri, @v);
}
#----------------------------------------------------------------------
sub do_logout {
    my $s = shift;

    check_session($s, 2);

    my ($dbh, %db);
    $dbh = $s->open_db('keys', \%db, LOCK_EX);
    delete $db{$s->sid}; 
    $s->close_db($dbh);
    
    return '19';    
}


#----------------------------------------------------------------------
sub mk_fields {
    my $s = shift;

    my @fields = split /,\s*/, $s->config->fields;
    Exception->throw(code=>'32') unless (scalar(@fields));
    return @fields;
}

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: USS.pm,v 1.10 2004/08/24 21:19:14 aleko Exp $

=cut

#######################################################################
