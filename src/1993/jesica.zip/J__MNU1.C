
 #include "j__const.h"
 #include "j__shell.h"


 int askpoint(int mode, float *a, float *b)
  {
     static char *p;
     char *pnt, b0, b1;
     int atr0=nmnatr, atr1=htatr, atr2=hbatr;
     int y1=33, y2=48, x1=5, x2=14, cnt=3, i,ii, j,cf;
     char *pict[8] = { "            ",
                       "   x> ....  ",
                       "            ",
                       "   y> ....  ",
                       "            ",
                       "            ",
                       "     Ok.    ",
                       "            " };
     struct { int x, y, len;
              char *str; }
              fld[3] = { {7,40,4,"    "},
                         {9,40,4,"    "},
                         {12,38,4," Ok."} };
     extern int numeq (char *str);
     if (!mode) { p=salloc (2*18*11,sizeof(char)); return 1; }
     save_video (x1,y1,x2,y2,p,1);
     clw (x1,y1,13,10,atr0);
     draw_border (x1,y1,x2,y2,atr2);
     for (i=0; i<8; i++)
         write_string (x1+1+i,y1+1,pict[i],atr0,12);
     for (i=0; i<cnt; i++)
         write_string (fld[i].x,fld[i].y,fld[i].str,atr1,fld[i].len);
     i=cf=0;
     do { write_string (fld[i].x,fld[i].y,fld[i].str,atr2,fld[i].len);
      	  goto_xy(fld[i].x,fld[i].y+fld[i].len);
bottom (" Enter - �롮�  Esc - �⬥��   Space - ������   Navi - ����� ");
          if (i==cnt-1) status ("���⢥ত���� �����");
             else status ("����室��� ����� �᫮");
	  ii=getsym();
          write_string (fld[i].x,fld[i].y,fld[i].str,atr1,fld[i].len);
          switch(ii) {
	       case KEsc    : cf=1; break;
               case KSTab   :
               case KCUp    :
	       case KCLeft  : if (i==cnt-1) { i--; break; }
                                 else if (numeq(fld[i].str))
                                       { if (i) i--; else i=cnt-1; }
                              break;
               case KCDown  :
               case KTab    :
	       case KCRight : if (i==cnt-1) { i=0; break; }
                                 else if (numeq(fld[i].str)) i++;
                              break;
	       case KEnter  :  if (i==cnt-1) { cf=2; break; }
                                  else if (numeq(fld[i].str)) i++;
                               break;
               default      :  if (i==cnt-1) break;
                               if (ii>='0' && ii<='9')
                                { if (*fld[i].str!=' ') break;
                                  for (j=0;j<fld[i].len-1;j++)
                                      *(fld[i].str+j)=*(fld[i].str+j+1);
                                      *(fld[i].str+fld[i].len-1)=ii;
                                  break;
                                }
                               switch (ii) {
	                       case KSpace : for (j=0;j<fld[i].len;j++)
                                                 *(fld[i].str+j)=' ';
                                             break;
	                       case KDel   : b1=' ';
                                             for (j=0;j<fld[i].len;j++)
                                               { b0=b1; b1=*(fld[i].str+j);
                                                 *(fld[i].str+j)=b0;
                                               }
                                             break;
                                          }
                    }  // main switch
        } while (!cf);
     cf--;
     restore_video(x1,y1,x2,y2,p,1);
     if (!cf) return 0;
     for (i=0;i<fld[0].len;i++) if (*(fld[0].str+i)!=' ')
         { pnt=fld[0].str+i; break; }
     *a=atoi(pnt);
     for (i=0;i<fld[1].len;i++) if (*(fld[1].str+i)!=' ')
         { pnt=fld[1].str+i; break; }
     *b=atoi(pnt);
     return 1;
 }
 int numeq (char *str)
   { int i,k;
     k=strlen(str);
     for (i=0;i<k && *(str+i)==' '; i++);
     if (i==k) return 0;
        else return 1;
   }
