package Apache::OverSSIApp::USSConfig;

# $Id: USSConfig.pm,v 1.2 2004/08/08 19:15:07 jean Exp $

=head1 NAME

Apache::OverSSIApp::USSConfig - Internal package

=head1 DESCRIPTION


=over 4

=cut
    
use strict;
use warnings;

use Params::Validate qw(:all);

use base qw(Apache::OverSSI::Config);

our $VERSION = sprintf("%d.%02d", '$Revision: 1.2 $' =~ /(\d+)\.(\d+)/);

BEGIN {
    __PACKAGE__->valid_params (
	fields => {
    	    type => SCALAR,
	    descr => 'Comma delimited list of form fields to store' 
	},
	addusers => {
    	    type => SCALAR, default => 0,
	    descr => 'user autoadding allowed if true' 
	},
	admin => {
    	    type => SCALAR,
	    descr => 'superuser email' 
	},
	mail => {
    	    type => SCALAR,
	    descr => 'Email template' 
	},
	from => {
    	    type => SCALAR,
	    descr => 'Email From header' 
	},
	smtp => {
    	    type => SCALAR, default => 0,
	    descr => 'smtp server hostname' 
	},

    );
}

use Apache::OverSSI::MethodMaker (
    read_only => [ 
	keys %{__PACKAGE__->validation_spec}
    ],
);

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: USSConfig.pm,v 1.2 2004/08/08 19:15:07 jean Exp $

=cut

#######################################################################
