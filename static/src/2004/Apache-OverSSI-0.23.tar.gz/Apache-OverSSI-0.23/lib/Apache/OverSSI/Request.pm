package Apache::OverSSI::Request;

# $Id: Request.pm,v 1.12 2004/08/24 16:48:57 jean Exp $

=head1 NAME

Apache::OverSSI::Request - class for Request object

=head1 DESCRIPTION

Apache::OverSSI is a library for lightweight mod_perl
applications which use SSI for output templating.
based on Apache, mod_perl, mod_include and mod_env.

=over 4

=cut

use strict;
use warnings;

use Params::Validate qw(:all);
use Apache::Constants qw(:common :response);
use Apache::Request;
use Apache::Session::Flex;

use Data::Dumper;

use base qw(Class::Container);

our $VERSION = sprintf("%d.%02d", '$Revision: 1.12 $' =~ /(\d+)\.(\d+)/);
our $DEBUG = 3;

BEGIN {
    # Fields that can be set in new method, with defaults
    __PACKAGE__->valid_params (
	server => { 
	    isa => 'Apache::OverSSI::Server',
	    descr => "Server object" 
	},
	request => { 
	    isa => 'Apache',
	    descr => "Request object" 
	},
    );
}

use Apache::OverSSI::MethodMaker (

    read_only => [ 
	keys %{__PACKAGE__->validation_spec}
    ],
    read_write => [ qw( 
	session
	sid
	apr
	unique_id
	config_uri
	data_dir
	config
	args
	uri
	stamp
	log_level
	page
    ) ],
);

use Apache::OverSSI::Exception;

#----------------------------------------------------------------------

=item new

new

=cut

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(@_);

    $self->{'args'} = {};
    $self->_initialize;
    return $self;
}

#----------------------------------------------------------------------

=item _initialize

_initialize

=cut


sub _initialize {
    my $self = shift;

    my $s = $self->server;
    my $r = $self->request;

    $self->config_uri($r->subprocess_env($s->module_name.'_CONFIG'));
    $self->log_level($r->subprocess_env($s->module_name.'_DEBUG') || $DEBUG);
    $self->page('index');
    $self->print_log(8, '*** Request ***');

}

#----------------------------------------------------------------------

=item load_conf

load conf
	__PACKAGE__::Config->new( 
	    $rec->load_conf(
		keys %{__PACKAGE__::Config->validation_spec}
	    )
	)

=cut


sub load_conf {
    my $self = shift;
    my @vars = @_;

    my $r = $self->request;
    $self->uri($r->subprocess_env('URI') || $r->subprocess_env('SCRIPT_NAME'));

    my %env = (
	URI	=> $self->uri,
    );
#    $self->print_log(8, Dumper(\%ENV));
    $self->include($self->config_uri, \%env, 0, @vars) or return undef;
    my @env;
    delete $env{'URI'}; # needed in include but not in validation
    foreach my $key (keys %env) {
	push @env, ($key, $env{$key});
    }
    return @env;
}

#----------------------------------------------------------------------

=item run

run

=cut

sub run {
    my $self = shift;
    my $config = shift;

    return NOT_FOUND unless ($config);
    $self->config($config);
    $self->log_level($config->log_level);
    $self->print_log(8, '* Run *');

    #$self->print_log(8, Dumper(\%ENV));
    
    my $s = $self->server;
    my $r = $self->request;
    my $r1= $self->r_main;

    # Per Request init

    my $st = localtime();
    $self->stamp($st);

    $self->unique_id($r->subprocess_env('UNIQUE_ID')) if ($self->server->use_unique_id);

    my $data_dir = $r->document_root();
    $data_dir =~ s :/[^/]+/?$::; # strip /public_html/
    $data_dir = $data_dir.'/'.$config->data_dir;;
    $self->print_log(8, "Data Dir: $data_dir");
    $self->data_dir($data_dir);

    my $apr = Apache::Request->new($r1, %{$s->request_params});
    my $status = $apr->parse;

    if ($status) {
	my $errmsg = $apr->notes("error-notes");
	$self->print_log(2, "Error creating Apache Request: $errmsg");
	$self->show_page(undef, 304, $s->request_params);
        return $status;
    }
    $self->apr($apr);

    
    $self->print_log(6, "URI :".$self->uri);
    $self->print_log(6, "ARGS:".$r->args) if ($r->args);

    # get session id
    my $sid = ($s->sid_param)?$apr->param($s->sid_param):$r1->notes('cookie');
    $self->sid( $sid || '' );
    # ToDo: Add client ip?
    $self->print_log(6, "sid: ".$self->sid);

    # get command 
    my $cmd=$s->cmd_param?$apr->param($self->server->cmd_param):$r->path_info();
    if ($cmd) { $cmd =~ s:^/::; };
    $cmd = $s->default_command unless($cmd);
    
    return NOT_FOUND unless $cmd;
    
    $self->print_log(6, "�ommand: $cmd");

    my %a = $r->args;
    $self->args(\%a);

    # fetch session
    $self->_session if ($config->session_id); 

    # do it
    my $ret;
    eval {
	$ret = &{$s->command($cmd)->func}($self);
	$self->print_log(6, "result: ".($ret || 'undef') );
    };
    if ( UNIVERSAL::isa( $@, &Exception ) ) {
	$ret = $@->code || '09';
	my $info = $@->info || '';
	$self->print_log(1, "ERROR [$ret]: $info");
    } elsif ($@) {
	$self->print_log(1, "ERROR [die]: $@");
	$ret = '09';
    }	
    $self->_session($self->session) if ($config->session_id); 

    return $ret?$self->show_page(undef, $ret):OK;
}	    

#----------------------------------------------------------------------
sub redirect {
    my $self = shift;
    my $uri = shift;
    my @arg = @_;

    my $s = $self->server;

    push (@arg, $s->sid_param.'='.$self->sid) if ($s->sid_param);

    my $arg = join '&', @arg;
    $arg = '?'.$arg if ($arg ne '');
    
    my $url = $uri.$arg;
    $self->print_log(4, "Redir to $url");
    $self->apr->header_out(Location => $url );
    $self->apr->status(REDIRECT);
    return REDIRECT;    
}

#----------------------------------------------------------------------

=item load_vars ($request, \%env, $add_undef, @vars)

load listed ENV/SSI vars from current/sub request
Undefined variables wont be added unless $add_undef

=cut

sub load_vars {
    my ($self, $req, $env, $add_undef, @vars) = @_;
    foreach my $var (@vars) {
	my $value = $req->subprocess_env($var);
	if ( defined($value) ) {
	    $self->print_log(8, "GETENV $var = $value");
	} elsif ($add_undef) {
	    $self->print_log(7, "GETENV $var undefined");
	} else {
	    $self->print_log(8, "GETENV $var undefined. Skip.");
	    next;
	}
	$env->{$var} = $value;
    }
}

#----------------------------------------------------------------------

=item store_vars ($request, \%env)

store hash values in request %ENV

=cut

sub store_vars {
    my ($self, $req, $env) = @_;

    foreach my $var (keys %$env) {
	    my $value = $env->{$var};
	    $value ||= '';
	    $req->subprocess_env($var, $value);
	    $self->print_log(8, "SETENV $var = $value");
    }
}

#----------------------------------------------------------------------

=item include ($uri, \%env, $add_undef, @vars)

Subrequest:
    - make subrequest to $uri, 
    - pass %env into its environment,
    - print text/html header unless @vars
    - run 
    - load @vars into %env
    
=cut

sub include {
    my ($self, $uri, $env, $add_undef, @vars) = @_;

    my $r = $self->request;

    $self->print_log(7, "include : $uri ");
    my $subr = $r->lookup_uri($uri);

    unless ( scalar(@vars) ) {
	# dont fetch values => just show page
	$r->content_type("text/html");
	$r->send_http_header();
    }

    $self->store_vars($subr, $env);
    if($subr->run != OK) {
	# don't need to log. Apache does.
	$self->print_log(8, "ERROR subrequesting $uri: ".$subr->notes("error-notes"));
	return undef;
    } elsif ( scalar(@vars) ) {
	$self->load_vars($subr, $env, $add_undef, @vars);
    }
    return 1;
}

#----------------------------------------------------------------------

=item show_page

show_page


=cut

sub show_page { 
    my ($self, $uri_tag, $code) = @_;
    my $prefix = $self->server->module_name;
    $self->args->{$prefix.'_CODE'} = '_'.$code.'_';
    $self->args->{'URI'} = $self->uri;
    $uri_tag ||= $self->page;
    $self->print_log(8, 'showing pagetag '.$uri_tag);
    my $uri = $self->config->page($uri_tag);
    if ($uri) {
	$self->print_log(8, "showing page $uri");
	return $self->include($uri, $self->args);
    } else {
	return NOT_FOUND;
    }
}

#----------------------------------------------------------------------

=item param

param

=cut

sub param {
    my $self = shift;
    return $self->apr->param(shift);
}    

#----------------------------------------------------------------------
# _session
# fetch/store session data

sub _session {
    my $self = shift;
    my $data = shift;

    my $s = $self->server;
    my %session;
    my $sid = $self->sid;
    my $id = $self->config->session_id;

    while (1) {
	eval {
	    tie %session, 'Apache::Session::Flex', $sid, {
		Store		=> 'DB_File',
    		FileName      	=> $self->data_dir().'/sessions.db',
		Lock      	=> 'File',
    		LockDirectory 	=> $self->data_dir,
    		Serialize 	=> 'Storable',
	        Generate  	=> 'ModUsertrack',
	        ModUsertrackCookieName => $self->config->cookie
	    };
	};
	if ( $@ ) {
	    if ( $@ =~ /Object does not exist/) {
		$sid = undef;
		next;
	    } else {
		$self->print_log(2, "Session create error: ".$@);
		return {};
	    }
	}
	last;
    }
    
    unless (exists($session{$id})) {
	$session{$id} = {
	    '_state' => 0
	};
    }	
    $self->session($session{$id});

    if ($data) {
	$session{$id} = $data;
    }
}
#----------------------------------------------------------------------

=item r_main

r_main - return result of ($r->is_main())?$r:$r->main();

=cut

sub r_main {
    my $self = shift;
    my $r = $self->request;
    return ($r->is_main())?$r:$r->main();
}

#----------------------------------------------------------------------

=item print_log

print_log

=cut

sub print_log {
    my ($self, $type, $err) = @_;
    my $r = $self->request;
    if ( $type <= $self->log_level ) {
	if ($r) {
	    $r->log_error($self->server->module_name." [$type]: $err") ;
	} else {
	    print STDERR "Error: $err\n";
	}
    }
}

#----------------------------------------------------------------------

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: Request.pm,v 1.12 2004/08/24 16:48:57 jean Exp $

=cut

#######################################################################
