// j__user

 #include "j__const.h"
 #include "j__shell.h"
 char *flname,
      *dsyms,
      *main_flags,
      *save_flags;

 int loc_flag=1,
     change_flag=1,
     step2_flag=0,
     vmrow=0,
     dsymnum,
     dstatrow, ddynrow, ddynelem, dstatelem,
     limdblk;

 line *dstatblk,   *ddynblk,  *vstatblk,  *vdynblk;
 vars *dstatvars, *ddynvars, *vstatvars, *vdynvars;

 void install();


 void install()
    {
      #include "j_u_inst.j"
      dstatrow=stat_rows;
      ddynrow=dyn_rows,
      dstatelem=stat_elem,
      ddynelem=dyn_elem,
      limdblk=lim_blk;
      flname=lib_name;
      dsyms=info;
      dsymnum=info_num;

   fulldata (dstatrow,dstatelem,stat_mask,types,&dstatblk,&dstatvars,dwcol,
					      dsvatr,dstatr);
   fulldata (ddynrow,ddynelem,dyn_mask,0,&ddynblk,&ddynvars,dwcol,
 					      ddvatr,ddtatr);
   { int i;
     for (i=0;i<strlen(dsyms);i++)
	 if (*(dsyms+i)=='/') *(dsyms+i)=DELIM;
   }
   { char *lf;
     int i;
     main_flags = salloc(5,1); lf="0101";
     for (i=0;i<5;i++) *(main_flags+i)=*(lf+i);
     save_flags = salloc(5,1); lf="0000";
     for (i=0;i<5;i++) *(save_flags+i)=*(lf+i);
   }
   }
