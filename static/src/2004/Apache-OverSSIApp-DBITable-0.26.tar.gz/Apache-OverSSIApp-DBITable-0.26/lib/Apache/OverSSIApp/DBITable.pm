package Apache::OverSSIApp::DBITable;

# $Id: DBITable.pm,v 1.13 2004/11/25 19:14:21 aleko Exp $

=head1 NAME

Apache::OverSSIApp::USS - User Settings System based on Apache::OverSSI

=head1 DESCRIPTION

Apache::OverSSIApp::DBITable is a simple utility for form data saving
and restoring with authorization via email
based on Apache::OverSSI library

=over 4

=cut
    
use strict;
use warnings;


use Fcntl qw(:flock);
use Apache::Constants qw(:common);

use Params::Validate qw(:all);

use Apache::OverSSI 0.21;
use Apache::OverSSI::Server;
use Apache::OverSSI::Request;
use Apache::OverSSI::Command;
use Apache::OverSSI::Utils;
use Apache::OverSSI::Exception;
use Apache::OverSSI::DBI;

use Apache::OverSSIApp::DBITableConfig;

use base qw(Apache::OverSSI::Request);

our $VERSION = '0.26';
our $REVISION = sprintf("%d.%02d", '$Revision: 1.13 $' =~ /(\d+)\.(\d+)/);

use POSIX qw(locale_h);
setlocale(LC_ALL,"ru_RU.koi8r");

my $srv; # ������������ ��� ���� ������:���������� ������ � ����������� ����������

use Data::Dumper;

BEGIN {

    $srv = Apache::OverSSI::Server->new(
	module_name => 'DBITable',

	# Default command name
	default_command	=> 'index',
    );

    $srv->command('index',     Apache::OverSSI::Command->new( func => \&do_index) );
}

use Apache::OverSSI::MethodMaker (
    read_write => [ 
	qw(f_select f_table)
    ],
);


#----------------------------------------------------------------------

=item handler

Main procedure. Initializes variables and calls
requested command

=cut

sub handler  {
    my $r = shift;

    my $mask = $r->subprocess_env($srv->module_name.'_CONFIGFMT');

    if ($mask) {
	# multipage
    
	my $uri = $r->path_info();
	if ($uri =~ m:^/(\w+)/?(.*)$:) {
	    $uri = $1;
	    $r->path_info("/$2");
	
	    my $file = sprintf $mask, $uri;
	    my $subr = $r->lookup_uri($file);
    	    my $filename = $subr->filename;
	    if ( -e $filename) {
		$r->subprocess_env($srv->module_name.'_CONFIG', $file);
	    } else {
		return NOT_FOUND;
	    }
	} else {
	    return NOT_FOUND;
	}
    }

    my $rec = __PACKAGE__->new(server => $srv, request => $r);
    my @config = $rec->load_conf(keys %{Apache::OverSSIApp::DBITableConfig->validation_spec})
	or return NOT_FOUND;
    return $rec->run( Apache::OverSSIApp::DBITableConfig->new(@config) );
}

#----------------------------------------------------------------------
# show
# ACL: Guest
# fill in form and show query result if args presents

sub do_index {
    my $self = shift;
    my $args = $self->args;
    
    #----------------------------------------------------------------------
    # ��������� �������/������������ ����������
    my @a;
    foreach my $key (keys %$args) {
	if (defined($args->{$key})) {
	    push @a, ($key, $args->{$key});
	}
    }

    # collect required args

    # ToDo: make defaults configurable
    my %can = (
	by => 	{ type => SCALAR, untaint => 1, regex => qr/^(\d+|-1)$/ , default => 20 },
	page =>	{ type => SCALAR, untaint => 1, regex => qr/^\d+$/ , default => 1  },
    );
    
    my $nc = $self->config->dates_count;
    my (@types, $format);
    if ($nc) {
	# ToDo: check if $n is number >0
	my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
	$mday = sprintf "%02i", $mday;
	$mon = sprintf "%02i", ++$mon;
	@types = split //,$self->config->dates_type;
	my @formats;
	foreach my $t (@types) {
	    my ($reg, $def);
	    if ($t eq 'd') {
		$reg = qr/^\d{1,2}$/; $def = $mday;
		push @formats, '%s';

	    } elsif ($t eq 'm') {
		$reg = qr/^\d{1,2}$/; $def = $mon;
		push @formats, '%02d';

	    } elsif ($t eq 'y') {
		$reg = qr/^\d{2,4}$/; $def = 1900 + $year;
		push @formats, '%s';

	    } else {
		Exception->throw( info => 'CONFIG: dates_type with unknown format: '.$t );
	    }
	    for (my $i = 0; $i<$nc; $i++) {
		$can{"$t$i"} = { type => SCALAR, untaint => 1, regex => $reg , default => $def };
	    }
	}
	$format = join '.', @formats; 
    }
    # additional args
    my @addtypes = split /\s/, $self->config->args;
    my $args_found;
    foreach my $t (@addtypes) {
	if ($t =~ /id/) {
	    $can{$t} = { type => SCALAR, untaint => 1, regex => qr/^[\w\.\^\|\(\)\d]*$/ , default => '' };
	} else {
	    Exception->throw( info => 'CONFIG: args with unknown arg name: '.$t );
	}
	$args_found++ if defined $args->{$t};
    }

    my %p;
    eval {
	%p = validate(@a, \%can);
    };

    $self->print_log(8, Dumper(\%can));
    if ($@) {
	$self->print_log(2, "Args validation errors: $@");
	return 11;
    }

    if ($self->config->session_id) {
	# session support mode
	my $session = $self->session();
	if ($session->{'_state'}<2) {
	    # user does not logged in
	    return $self->redirect($self->config->session_logon);
	} else {
	    $session->{'_active'} = time();
	    # store session in ENV
	    $self->store_vars($self->r_main, $session);
	    # ToDo: make name 'id' configurable
	    $p{'id'} = $session->{$self->config->session_key};
	}
    }

    $self->args(\%p);

    #----------------------------------------------------------------------
    # ���������� � ��
    my $dbh = db_connect($self->config);
    $dbh->do("set datestyle to 'German'");
    #----------------------------------------------------------------------
    # ������ ����� ��������� ���. ������
    my $psql = $self->config->pre_sql;
    if ($psql) {
	my $data = $dbh->selectall_arrayref($psql);
	$self->f_select($data);
	$p{'D_SELECT'}='SSI_SEL1';
	$self->request->pnotes('SSI_SEL1', $data);
    }

    #----------------------------------------------------------------------
    # ���������� �������

    # exit if required id does not exist
    return 12 unless ($self->config->do_empty or $args_found); 

    # fill args list
    my @args;
    if ($nc) {
	for (my $i = 0; $i<$nc; $i++) {
	    push @args, sprintf ($format, map { $p{"$_$i"} } @types);
	}
    }
    foreach my $t (@addtypes) {
	push @args, $p{$t};
    }
        
    $self->print_log(8, Dumper(\@args));
    my $sql=$self->config->sql;

    my $navy = db_select($dbh, $sql, \@args, $p{'by'}, $p{'page'}) or return 13;
    my $data = delete $navy->{'data'};
    foreach my $key (keys %$navy) {
	$p{$key} = $navy->{$key};
    }

    $self->f_table($data);
    $p{'D_TABLE'} = 'SSI_TBL1';
    $self->request->pnotes('SSI_TBL1', $data);

    return 10;
}

1;

__END__


=head1 AUTHOR
    
    Alexey Kovrizhkin <aleko@jast.ru>

=head1 VERSION

    $Id: DBITable.pm,v 1.13 2004/11/25 19:14:21 aleko Exp $

=cut

#######################################################################
